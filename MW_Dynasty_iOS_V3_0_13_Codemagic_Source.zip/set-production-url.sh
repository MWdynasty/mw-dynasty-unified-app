#!/usr/bin/env bash
set -euo pipefail
URL="${1:-}"
if [[ -z "$URL" || "$URL" != https://* ]]; then
  echo "Usage: ./set-production-url.sh https://your-production-domain.example"
  exit 1
fi
PLIST="$(cd "$(dirname "$0")" && pwd)/MWDynasty/Info.plist"
python3 - "$PLIST" "$URL" <<'PY'
import plistlib,sys
path,url=sys.argv[1:]
with open(path,'rb') as f: data=plistlib.load(f)
data['MWProductionURL']=url.rstrip('/')
with open(path,'wb') as f: plistlib.dump(data,f,fmt=plistlib.FMT_XML,sort_keys=False)
print('MWProductionURL set to',data['MWProductionURL'])
PY
