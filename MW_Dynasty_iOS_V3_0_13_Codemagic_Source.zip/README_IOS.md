# MW Dynasty iPhone — Launch Candidate 3.0.13 (Build 4)

This is the native iPhone shell for MW Dynasty. It loads the public production app at:

`https://mwdynastyv3011communicationsearchbillingqa.vercel.app`

## Native capabilities
- WKWebView production shell
- Location permission bridge for Distance Marker
- Microphone + Speech Recognition permission bridge for Coach MW voice input
- Camera and Photo Library purpose strings for optional image upload
- Native launch screen and MW Dynasty app icon
- Connection/error handling

## App identity
- Bundle identifier: `com.mwdynasty.app`
- Marketing version: `3.0.13`
- Local build number: `4`
- Minimum iOS: `17.0`

## Codemagic
The repository root contains `codemagic.yaml`. The first workflow performs an unsigned iOS Simulator compile check in Codemagic. After that passes, App Store Connect signing is connected and the TestFlight workflow is enabled.

## Final device QA before App Store submission
Verify on a physical iPhone through TestFlight: athlete login, coach login, account deletion, Coach Support, Coach MW voice input/output, Distance Marker GPS, image upload, pace check-ins, messages, search, notifications, and sign-out/sign-in.
