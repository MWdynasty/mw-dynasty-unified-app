const app=document.getElementById('app');
const SUPABASE_URL='https://keqgunlfwhjgcsurynef.supabase.co';
const SUPABASE_KEY='sb_publishable_JWCLQzrdWA_ZmvbpV5urVg_rcT6NECm';
const SESSION_KEY='mwCoachSupabaseSession';
const MW_APP_VERSION='3.0.16';
const MW_IOS_BUILD='5';
let authSession=null;
let accountAccess={role:null,tier:null,isFounder:false};

const PLANS={
 core:{name:'MW Coach Core',theme:'',title:'MW COACH CORE',tag:'MANAGE. ORGANIZE. COACH.',sub:'Bring Your Own Program — Built for Coaches.',side:'COACH\nCORE',footer:'BUILD\nDEVELOP\nCOMPETE',planCode:'coach_core',monthly:49,sponsor:5},
 intelligence:{name:'MW Coach Intelligence',theme:'blue',title:'MW COACH INTELLIGENCE',tag:'YOUR PROGRAM. AMPLIFIED.',sub:'Bring Your Own Program + Full AI Intelligence.',side:'COACH\nINTELLIGENCE',footer:'DATA\nINTELLIGENCE\nRESULTS',planCode:'coach_intelligence',monthly:79,sponsor:6},
 performance:{name:'MW Sprint Performance System',theme:'gold',title:'MW SPRINT PERFORMANCE SYSTEM',tag:'PROVEN SPEED. A STRONGER FUTURE.',sub:'Complete MW System + Full AI Intelligence.',side:'PERFORMANCE\nSYSTEM',footer:'SPEED\nINTELLIGENCE\nLEGACY',planCode:'mw_sprint_performance',monthly:109,sponsor:7}
};
let pricingCatalogLoaded=false;
function centsToDollars(cents,fallback){const n=Number(cents);return Number.isFinite(n)?n/100:fallback}
async function loadPricingCatalog(){
  try{
    const r=await fetch('/api/pricing',{cache:'no-store'}),d=await r.json().catch(()=>({}));
    if(!r.ok||!Array.isArray(d.plans))throw new Error(d.error||'Pricing lookup failed');
    const byCode=new Map(d.plans.map(p=>[p.plan_code,p]));
    for(const p of Object.values(PLANS)){
      const live=byCode.get(p.planCode);if(!live)continue;
      p.monthly=centsToDollars(live.monthly_price_cents,p.monthly);
      p.sponsor=centsToDollars(live.sponsored_athlete_price_cents,p.sponsor);
    }
    pricingCatalogLoaded=true;
    return d.plans;
  }catch(e){console.warn('MW pricing catalog unavailable; using built-in locked fallback prices.',e);return null}
}
let experience='core';
const nav={
 core:[['dashboard','⌂','Home'],['athletes','♟','Athletes'],['programs','🏃','Training'],['messages','✉','Messages'],['more','•••','More']],
 intelligence:[['dashboard','⌂','Home'],['athletes','♟','Athletes'],['programs','🏃','Training'],['insights','▱','Intelligence'],['more','•••','More']],
 performance:[['dashboard','⌂','Home'],['athletes','♟','Athletes'],['mwtrack','🏃','Training'],['insights','▱','Intelligence'],['more','•••','More']]
};
function sideNav(){const items=[...nav[experience]];return items.map(([id,ic,label])=>`<button class="nav-btn ${id==='dashboard'?'active':''}" data-page="${id}"><span class="nav-icon">${ic}</span><span>${label}</span></button>`).join('')}
function shell(content){const p=PLANS[experience];app.innerHTML=`<div class="app ${p.theme}"><div class="top-ribbon"><span>THREE PLATFORMS. ONE ECOSYSTEM.</span><span>${experience==='performance'?'SAME FOUNDATION. DIFFERENT POWER.':'GREATER ATHLETES. BETTER COACHES. A STRONGER FUTURE.'}</span></div><div class="frame"><header class="brand-head"><div class="brand-title">${p.title}</div><div class="brand-tag">${p.tag}</div><div class="brand-sub">${p.sub}</div></header><div class="workspace"><aside class="sidebar"><div class="side-brand-row"><div class="side-logo"><span class="mw-mark">MW</span><span>${p.side.replace('\n','<br>')}</span></div><button class="mobile-menu" id="mobileMenu" type="button" aria-expanded="false" aria-controls="sideNav">Menu</button></div><nav class="side-nav" id="sideNav">${sideNav()}</nav><div class="side-account"><div class="coach-row"><img class="avatar" src="coach-mw-reference.jpg" alt="Coach Williams"><div><div class="coach-name">Coach Williams</div><div class="coach-role">Head Coach</div></div></div><button class="signout" id="signout">Sign Out</button></div></aside><main class="main">${content}</main></div><footer class="footer"><div class="footer-brand">MW DYNASTY</div><div class="footer-mid">GREATER ATHLETES. BETTER COACHES. A STRONGER FUTURE.</div><div class="footer-right">${p.footer}</div></footer></div></div>`; bindGlobal();hydrateLiveAthleteCount();}
function topbar(placeholder){return `<div class="topbar"><div class="mw-search-wrap"><label class="search">⌕<input id="dashSearch" autocomplete="off" placeholder="${placeholder}"></label><div id="dashSearchResults" class="mw-search-results" hidden></div></div><button class="icon-btn mw-notification-btn" id="notificationBell" type="button" aria-label="Notifications">🔔<span id="notificationBadge" class="mw-notification-badge" hidden>0</span></button></div>`}
function stats(items){return `<div class="stats">${items.map(([n,l])=>`<button class="stat" data-stat="${l}"><b>${n}</b><span>${l}</span></button>`).join('')}</div>`}
function athleteStatusClassify(a){
  const now=Date.now();
  const last=a?.last_completed_workout_at?new Date(a.last_completed_workout_at).getTime():0;
  const days=last?Math.max(0,(now-last)/86400000):null;
  const hasPr=Array.isArray(a?.prs)&&a.prs.length>0;
  const explicit=String(a?.status||'').toLowerCase();
  const reasons=[];
  let level='ontrack';
  const perf=a?.performance||null,perfFlags=Array.isArray(perf?.flags)?perf.flags:[],latest=perf?.sprint?.latest||null;
  if(perfFlags.some(f=>f.level==='attention')){level='attention';reasons.push(perfFlags.find(f=>f.level==='attention')?.message||'Performance execution needs review')}
  else if(perfFlags.some(f=>f.level==='watch')){level='watch';reasons.push(perfFlags.find(f=>f.level==='watch')?.message||'Performance trend worth watching')}
  else if(latest?.execution_score_pct!=null){reasons.push(`${latest.execution_score_pct}% pace execution in latest check-in`)}
  if(days!==null&&days>14){level='attention';reasons.push(`No recorded workout in ${Math.floor(days)} days`)}
  else if(days===null){if(level==='ontrack')level='watch';reasons.push('No completed workout recorded yet')}
  else if(days>7){if(level==='ontrack')level='watch';reasons.push(`Last workout ${Math.floor(days)} days ago`)}
  if(!hasPr){if(level==='ontrack')level='watch';reasons.push('PR data incomplete')}
  if(/attention|at risk|behind|inactive/.test(explicit)){level='attention';reasons.unshift(a.status)}
  else if(/watch|monitor|review/.test(explicit)&&level!=='attention'){level='watch';reasons.unshift(a.status)}
  if(!reasons.length)reasons.push('Training activity and athlete data are current');
  return {level,reasons:[...new Set(reasons)]};
}
function athleteStatusLabel(level){return level==='attention'?'Needs Attention':level==='watch'?'Watch':'On Track'}
function athleteStatusBoardShell(){return `<section class="section athlete-status-section"><div class="section-head"><div><div class="status-kicker">LIVE ROSTER INTELLIGENCE</div><h2>Athlete Status Board</h2><p class="status-subcopy">See who is on track, who to watch, and who needs your attention.</p></div><button class="link-btn" data-page="athletes">View Athletes →</button></div><div id="athleteStatusBoard" class="athlete-status-board"><div class="tile">Analyzing live athlete status…</div></div></section>`}
async function hydrateAthleteStatusBoard(){
  const el=document.getElementById('athleteStatusBoard');if(!el)return;
  try{
    const [d,p]=await Promise.all([fetchCoachRoster(),fetchCoachPerformance().catch(()=>({athletes:[]}))]),athletes=Array.isArray(d.athletes)?d.athletes:[],perfMap=new Map((p.athletes||[]).map(x=>[x.athlete_id,x]));
    const groups={ontrack:[],watch:[],attention:[]};
    for(const raw of athletes){const a={...raw,performance:perfMap.get(raw.id)||null},c=athleteStatusClassify(a);groups[c.level].push({...a,_status:c})}
    const summary=`<div class="status-summary"><div class="status-summary-card ontrack"><span class="status-dot"></span><b>${groups.ontrack.length}</b><small>On Track</small></div><div class="status-summary-card watch"><span class="status-dot"></span><b>${groups.watch.length}</b><small>Watch</small></div><div class="status-summary-card attention"><span class="status-dot"></span><b>${groups.attention.length}</b><small>Needs Attention</small></div></div>`;
    const ordered=[...groups.attention,...groups.watch,...groups.ontrack];
    const cards=ordered.slice(0,12).map(a=>{const level=a._status.level;const reason=a._status.reasons[0];const event=a.event||a.primary_event||'Event not set';const week=Number(a.current_week||1);const acc=a.performance?.sprint?.latest?.execution_score_pct;return `<button class="athlete-status-card ${level}" data-athlete-id="${escapeHtml(a.id)}"><div class="athlete-status-top"><span class="status-pill ${level}"><span class="status-dot"></span>${athleteStatusLabel(level)}</span><span class="athlete-status-week">WEEK ${week}</span></div><h3>${escapeHtml(a.name||'Athlete')}</h3><p>${escapeHtml(event)}</p><div class="athlete-status-reason">${escapeHtml(reason)}</div><div class="athlete-status-foot"><span>${acc!=null?`Pace execution ${acc}%`:a.last_completed_workout_at?`Last workout ${escapeHtml(fmtDate(a.last_completed_workout_at))}`:'No performance data yet'}</span><span>Open →</span></div></button>`}).join('');
    el.innerHTML=summary+(cards?`<div class="athlete-status-grid">${cards}</div>`:`<div class="tile"><h3>No athletes connected yet</h3><p>Connect athletes to activate roster intelligence.</p></div>`);
    el.querySelectorAll('[data-athlete-id]').forEach(b=>b.onclick=()=>athleteDetail(b.dataset.athleteId));
  }catch(e){el.innerHTML=`<div class="tile"><h3>Status board unavailable</h3><p>${escapeHtml(e.message)}</p></div>`}
}
function coachPhaseName(phase){return ({1:'Foundation',2:'Strength & Speed Development',3:'Power / Pre-Competition',4:'Competition',5:'Peak / Championship'})[Number(phase)]||'MW Progression'}
function coachTrainingYearShell(){return `<button type="button" class="coach-training-year-card" data-page="account"><span class="coach-training-year-icon">▣</span><span class="coach-training-year-copy"><small id="coachTrainingYearLabel">MW TRAINING YEAR</small><b id="coachTrainingYearMain">Loading your training calendar…</b><span id="coachTrainingYearSub">Standard calendar + coach-controlled placement</span></span><span class="coach-training-year-arrow">→</span></button>`}
async function hydrateCoachTrainingYearCard(){
  const label=document.getElementById('coachTrainingYearLabel'),main=document.getElementById('coachTrainingYearMain'),sub=document.getElementById('coachTrainingYearSub');if(!main)return;
  try{
    const cal=await coachSeasonCalendarRequest();const custom=cal?.mode==='custom';
    if(label)label.textContent=custom?'CUSTOM TRAINING CALENDAR':'MW STANDARD TRAINING YEAR';
    if(cal?.status==='active')main.textContent=`Week ${cal.week} of 41 · ${coachPhaseName(cal.phase)}`;
    else if(cal?.status==='preseason')main.textContent='Preseason · Week 1 begins on your training-year start';
    else main.textContent='Between 41-week cycles · Foundation entry protected';
    if(sub)sub.textContent=custom?'Assigned athletes inherit your coach calendar and placement.':'Standard Week 1 begins the day after Labor Day · late joiners use Smart Entry.';
  }catch(e){main.textContent='Training calendar unavailable';if(sub)sub.textContent='Open Account to review the MW training-year setting.'}
}
function simpleCoachHome(primaryPage,primaryLabel,showIntel=false){
  const intel=showIntel?`<section class="section simple-section"><div class="section-head"><div><div class="status-kicker">PERFORMANCE</div><h2>What Needs My Attention?</h2><p class="status-subcopy">MW turns athlete check-ins into simple coach signals.</p></div><button class="link-btn" data-page="insights">OPEN →</button></div><div id="performanceInsightPreview" class="insight-list"><div class="tile">Checking athlete performance…</div></div></section>`:'';
  const statCards=showIntel?stats([['—','Athletes'],['—','Pace Execution']]):stats([['—','Athletes']]);
  shell(`${topbar('Search athletes...')}<section class="mw-coach-dashboard-visual simple-hero"><img src="/assets/mw-coach-dashboard-v23.jpg" alt="MW Dynasty Coach Dashboard"></section>${statCards}${coachTrainingYearShell()}<section class="simple-start"><div><span class="status-kicker">START HERE</span><h2>What do you want to do?</h2><p>Big buttons. Simple choices. The deeper tools are under More.</p></div><div class="simple-actions"><button data-page="athletes"><b>👥</b><span>MY ATHLETES<small>See the people I coach</small></span></button><button data-page="${primaryPage}"><b>🏃</b><span>${primaryLabel}<small>Open the training plan</small></span></button>${showIntel?'<button data-page="insights"><b>🧠</b><span>INTELLIGENCE<small>See who needs attention</small></span></button>':''}</div></section>${showIntel?athleteStatusBoardShell():''}${intel}`)
}
function coreDashboard(){simpleCoachHome('programs','TRAINING',false)}
function intelligenceDashboard(){simpleCoachHome('programs','TRAINING',true)}
function performanceDashboard(){simpleCoachHome('mwtrack','MW TRAINING',true)}
function dashboard(){
  if(experience==='core')coreDashboard();
  else if(experience==='intelligence'){intelligenceDashboard();hydrateAthleteStatusBoard();hydrateLivePerformanceSummary();hydratePerformanceInsightPreview();}
  else {performanceDashboard();hydrateAthleteStatusBoard();hydrateLivePerformanceSummary();hydratePerformanceInsightPreview();}
  hydrateCoachTrainingYearCard();
  window.setTimeout(()=>maybeStartCoachTour(),180);
}
function pageBase(title,subtitle,body){const p=PLANS[experience];app.innerHTML=`<div class="page ${p.theme}"><div class="page-wrap"><div class="page-top"><button class="back" id="back">← Dashboard</button><div style="flex:1"><div class="eyebrow">${p.name}</div><h1>${title}</h1><div style="color:#adbdc8">${subtitle}</div></div>${accountAccess.isFounder?'<button class="switch" id="switch">Founder Preview</button>':''}</div><div class="panel">${body}</div></div></div>`;document.getElementById('back').onclick=dashboard;const sw=document.getElementById('switch');if(sw)sw.onclick=membershipPage;bindPageActions();bindPageNavigation(app);}
function morePage(){
  const common=[['teams','👥','Teams'],['calendar','📅','Calendar'],['meets','🏁','Meets'],['attendance','✅','Attendance'],['messages','💬','Messages'],['activity','◔','Activity Log'],['account','⚙️','Account'],['support','?','Help']];
  const smart=experience==='core'?[]:[['coachmw','🧠','Coach MW'],['taskboard','☑','Task Board'],['season','📅','Season Planner'],['adjustment','↔','Season Adjustment']];
  const mw=experience==='performance'?[['strength','🏋️','Strength & Power'],['school','🎓','Sprint School'],['race','🏁','Race Strategy'],['pacing','⏱️','Pacing Tools']]:[];
  const founder=accountAccess.isFounder?[['coachapps','✓','Coach Applications']]:[];
  const items=[...mw,...smart,...common,...founder];
  pageBase('More','Everything else is here when you need it.',`<div class="simple-more-grid">${items.map(([id,ic,label])=>`<button data-page="${id}"><b>${ic}</b><span>${label}</span><em>→</em></button>`).join('')}</div>`)
}
function teamsPage(){pageBase('Teams','Manage squads, groups and coach assignments.',`<div class="panel-grid">${['Varsity Sprint Group','Development Group','400m Group','Relays'].map(n=>`<div class="tile"><h3>${n}</h3><p>Roster, attendance, messages and assignments.</p><button class="action" data-toast="Opened ${n}" style="margin-top:12px">Open Team</button></div>`).join('')}</div>`)}
function programsPage(){pageBase(experience==='performance'?'MW Track Program':'My Program',experience==='performance'?'41-week MW training system.':'Bring your own program and manage workouts.',`<div class="form"><textarea rows="9">Monday — Acceleration\nTuesday — Tempo + Strength\nWednesday — Recovery\nThursday — Max Velocity\nFriday — Speed Endurance</textarea><button class="action" data-toast="Program saved">Save Program</button></div>`)}
function calendarPage(){pageBase('Calendar','Practice, meet and team schedule.',`<div class="list"><div class="row"><span>APR 12 · Spring Invitational</span><button class="action" data-toast="Meet opened">Open</button></div><div class="row"><span>APR 19 · County Championship</span><button class="action" data-toast="Meet opened">Open</button></div><div class="row"><span>MAY 3 · State Qualifier</span><button class="action" data-toast="Meet opened">Open</button></div></div>`)}
function meetsPage(){pageBase('Meets','Manage registration and meet readiness.',`<div class="list"><div class="row"><span><b>Spring Invitational</b><br>Huntsville, AL</span><button class="action" data-toast="Registration opened">Registered</button></div><div class="row"><span><b>County Championship</b><br>Birmingham, AL</span><button class="action" data-toast="Registration opened">Registered</button></div><div class="row"><span><b>State Qualifier</b><br>Montgomery, AL</span><button class="action" data-toast="Registration started">Register</button></div></div>`)}
function messagesPage(){pageBase('Messages','Communicate with athletes and teams.',`<div class="form"><textarea rows="6" placeholder="Message the team..."></textarea><button class="action" data-toast="Message sent">Send Message</button></div>`)}
function activityPage(){pageBase('Activity Log','Recent coach and athlete activity.',`<div class="list"><div class="row"><span>Azel Johnson added to team</span><small>3 hours ago</small></div><div class="row"><span>Attendance updated</span><small>Yesterday</small></div><div class="row"><span>Workout edited</span><small>Yesterday</small></div></div>`)}
function supportPage(){pageBase('Help & Support','MW Dynasty coach support.',`<div class="form"><input placeholder="Subject"><textarea rows="6" placeholder="How can we help?"></textarea><button class="action" data-toast="Support request prepared">Submit Request</button></div>`)}
function taskBoardPage(){pageBase('AI Task Board','Daily coaching tasks and priorities.',`<div class="list"><div class="row"><span><b>Maya T. — Missed Training</b><br>Review workload before next high-intensity day.</span><button class="action" data-toast="Task reviewed">Review</button></div><div class="row"><span><b>Tyler B. — Performance Trend</b><br>Flying 30 trend improved across three sessions.</span><button class="action" data-toast="Task approved">Approve</button></div><div class="row"><span><b>Aaliyah R. — Meet Preparation</b><br>Competition warm-up and race-model review are due.</span><button class="action" data-toast="Task opened">Open</button></div></div>`)}
function seasonPage(){pageBase('AI Season Planner','Build and optimize the season while keeping the coach in control.',`<div class="panel-grid"><div class="tile"><h3>Current Phase</h3><p>Acceleration Development · Week 12</p></div><div class="tile"><h3>Next Meet</h3><p>Spring Invitational · APR 12</p></div></div><button class="action" data-toast="Season recommendation generated" style="margin-top:14px">Generate Recommendation</button>`)}
function adjustmentPage(){pageBase('AI Season Adjustment','Detect → Analyze → Recommend → Coach Approves → System Executes.',`<div class="tile"><h3>Recommended Adjustment</h3><p>Maya T. missed two sessions. Hold the next high-intensity progression until attendance and readiness are reviewed.</p><button class="action" data-toast="Recommendation approved" style="margin-top:12px">Approve Adjustment</button> <button class="back" data-toast="Recommendation dismissed">Dismiss</button></div>`)}
function coachMWPrefs(){
  try{return {...{coachType:'male',voiceSpeed:1},...(JSON.parse(localStorage.getItem('mwCoachAISettings')||'{}')||{})}}catch{return {coachType:'male',voiceSpeed:1}}
}
function coachMWSettingsHTML(){
  const pref=coachMWPrefs();
  return `<div class="tile" id="coachMWSettings"><h3>Coach MW Settings</h3><p>Choose the Coach MW voice and visual once. Coach Intelligence loads this preference automatically.</p><div class="form" style="grid-template-columns:1fr 1fr"><label>Coach MW<select id="coachMWType"><option value="male" ${pref.coachType==='male'?'selected':''}>Male Coach MW</option><option value="female" ${pref.coachType==='female'?'selected':''}>Female Coach MW</option></select></label><label>Voice Speed<select id="coachMWVoiceSpeed"><option value="0.9" ${Number(pref.voiceSpeed)===0.9?'selected':''}>0.9× Relaxed</option><option value="1" ${Number(pref.voiceSpeed)===1?'selected':''}>1.0× Natural</option><option value="1.1" ${Number(pref.voiceSpeed)===1.1?'selected':''}>1.1× Quick</option><option value="1.2" ${Number(pref.voiceSpeed)===1.2?'selected':''}>1.2× Fast</option></select></label></div><button class="action" id="saveCoachMWSettings" style="margin-top:12px">Save Coach MW Settings</button></div>`;
}
function bindCoachMWSettings(){
  const btn=document.getElementById('saveCoachMWSettings');if(!btn)return;
  btn.onclick=()=>{const prefs={coachType:document.getElementById('coachMWType')?.value==='female'?'female':'male',voiceSpeed:Number(document.getElementById('coachMWVoiceSpeed')?.value||1)};localStorage.setItem('mwCoachAISettings',JSON.stringify(prefs));btn.textContent='✓ Saved';setTimeout(()=>btn.textContent='Save Coach MW Settings',1000)};
}
function seasonCalendarSettingsHTML(){
  return `<div class="tile" id="seasonCalendarSettings"><h3>MW Training Year</h3><p>Use the MW Standard Training Year, or set a custom Week 1 start when your team calendar needs a different date. Assigned athletes follow the coach calendar and placement.</p><div class="form" style="grid-template-columns:1fr 1fr"><label>Training Calendar<select id="seasonCalendarMode"><option value="standard">MW Standard Training Year</option><option value="custom">Custom Week 1 Start</option></select></label><label id="seasonCalendarStartWrap">Custom Week 1 Start Date<input id="seasonCalendarStart" type="date"></label></div><div id="seasonCalendarSummary" class="tile" style="margin-top:12px"><small>Loading current training year…</small></div><button class="action" id="saveSeasonCalendar" type="button" style="margin-top:12px">Save Training Year</button></div>`;
}
function seasonCalendarSummaryHTML(calendar){
  const c=calendar||{},mode=c.mode==='custom'?'Custom':'MW Standard',week=Number(c.week||1),phase=Number(c.phase||1),status=String(c.status||'active');
  const statusLabel=status==='preseason'?'Preseason':status==='offseason'?'Offseason':'Active';
  return `<b>${escapeHtml(mode)} Training Year</b><br><small>${statusLabel} · Week ${week} · Phase ${phase}${c.startDate?' · Week 1: '+escapeHtml(c.startDate):''}</small>`;
}
function bindSeasonCalendarSettings(){
  const root=document.getElementById('seasonCalendarSettings');if(!root)return;
  const mode=root.querySelector('#seasonCalendarMode'),start=root.querySelector('#seasonCalendarStart'),wrap=root.querySelector('#seasonCalendarStartWrap'),summary=root.querySelector('#seasonCalendarSummary'),save=root.querySelector('#saveSeasonCalendar');
  const sync=()=>{if(wrap)wrap.style.display=mode?.value==='custom'?'grid':'none'};
  if(mode){mode.onchange=sync;sync()}
  const token=mwSessionToken();
  if(!token){if(summary)summary.innerHTML='<small>Sign in again to manage the training year.</small>';if(save)save.disabled=true;return}
  fetch('/api/season-calendar',{headers:{Authorization:`Bearer ${token}`},cache:'no-store'}).then(async r=>{const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.error||'Training year unavailable');const c=d.calendar||{};if(mode)mode.value=c.mode==='custom'?'custom':'standard';if(start)start.value=c.mode==='custom'&&c.startDate?c.startDate:'';sync();if(summary)summary.innerHTML=seasonCalendarSummaryHTML(c)}).catch(e=>{if(summary)summary.innerHTML=`<small>${escapeHtml(e.message||'Training year unavailable')}</small>`});
  if(save)save.onclick=async()=>{const selected=mode?.value==='custom'?'custom':'standard',startDate=start?.value||'';if(selected==='custom'&&!startDate)return toast('Choose the custom Week 1 start date.');const old=save.textContent;save.disabled=true;save.textContent='Saving…';try{const r=await fetch('/api/season-calendar',{method:'POST',headers:{Authorization:`Bearer ${mwSessionToken()}`,'Content-Type':'application/json'},body:JSON.stringify({mode:selected,startDate:selected==='custom'?startDate:null})});const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.error||'Training year could not be saved');if(summary)summary.innerHTML=seasonCalendarSummaryHTML(d.calendar||{});toast('Training year saved')}catch(e){if(summary)summary.innerHTML=`<small>${escapeHtml(e.message||'Training year could not be saved')}</small>`}finally{save.disabled=false;save.textContent=old}};
}
function coachMWPage(){
  pageBase('Coach MW AI','MW intelligence in the same Dynasty experience.',`
  <div class="form">
    <div class="tile"><b>Coach MW</b><p>Ask about athletes, teams, attendance, progression, pace check-ins, race strategy, your program, or the MW system. Your Coach MW voice preference is managed in Account Settings.</p></div>
    <div id="mwchat" style="display:grid;gap:10px;max-height:460px;overflow:auto"></div>
    <div class="mw-coach-input-row">
      <button class="back" id="mwmic" title="Speak to Coach MW" aria-label="Speak to Coach MW">🎙</button>
      <button class="back" id="mwattach" title="Add photo" aria-label="Add photo">＋</button>
      <input id="mwimage" type="file" accept="image/png,image/jpeg,image/webp" style="display:none">
      <input id="mwq" placeholder="Ask Coach MW anything...">
      <button class="action" id="askmw">Ask</button>
    </div>
    <div id="mwattachstate" class="mw-coach-state"></div>
  </div>`);
  let pendingImage='',activeAudio=null;
  const chat=document.getElementById('mwchat'),q=document.getElementById('mwq'),pick=document.getElementById('mwimage'),attach=document.getElementById('mwattach'),mic=document.getElementById('mwmic'),state=document.getElementById('mwattachstate');
  let history=[];try{history=JSON.parse(sessionStorage.getItem('mwCoachProConversation')||'[]')}catch{}
  const readAloud=async(text,button)=>{
    if(activeAudio){try{activeAudio.pause()}catch{}activeAudio=null}
    const prefs=coachMWPrefs(),token=mwSessionToken();if(!token)return toast('Coach session expired. Sign in again.');
    const old=button.textContent;button.disabled=true;button.textContent='Loading voice…';
    try{const r=await fetch('/api/speak',{method:'POST',headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json'},body:JSON.stringify({text,coachType:prefs.coachType})});if(!r.ok){const d=await r.json().catch(()=>({}));throw new Error(d.error||'Coach MW voice unavailable')}const blob=await r.blob(),url=URL.createObjectURL(blob),audio=new Audio(url);audio.playbackRate=Number(prefs.voiceSpeed||1);activeAudio=audio;button.textContent='■ Stop';button.disabled=false;button.onclick=()=>{audio.pause();button.textContent='🔊 Read Aloud';activeAudio=null;URL.revokeObjectURL(url)};audio.onended=()=>{button.textContent='🔊 Read Aloud';button.onclick=()=>readAloud(text,button);activeAudio=null;URL.revokeObjectURL(url)};await audio.play()}catch(e){button.disabled=false;button.textContent=old;toast(e.message)}
  };
  const render=()=>{chat.innerHTML=history.map((m,i)=>`<div class="tile mw-coach-message ${m.role==='user'?'mw-coach-user':'mw-coach-assistant'}"><b>${m.role==='user'?'Coach':'Coach MW'}</b><p style="white-space:pre-wrap">${escapeHtml(m.content)}</p>${m.role==='assistant'?`<button class="back mw-read-aloud" data-i="${i}" type="button">🔊 Read Aloud</button>`:''}</div>`).join('');chat.querySelectorAll('.mw-read-aloud').forEach(b=>{const item=history[Number(b.dataset.i)];b.onclick=()=>readAloud(item?.content||'',b)});chat.scrollTop=chat.scrollHeight};
  render();
  attach.onclick=()=>pick.click();
  pick.onchange=()=>{const f=pick.files?.[0];if(!f)return;if(f.size>3*1024*1024){state.textContent='Photo too large. Use 3 MB or less.';pick.value='';return}const r=new FileReader();r.onload=()=>{pendingImage=String(r.result||'');state.textContent='Photo attached.'};r.readAsDataURL(f)};
  const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
  if(SR){const recognition=new SR();recognition.lang='en-US';recognition.interimResults=false;recognition.continuous=false;recognition.onstart=()=>{mic.classList.add('listening');mic.textContent='●';state.textContent='Listening…'};recognition.onresult=e=>{const text=e.results?.[0]?.[0]?.transcript||'';if(text){q.value=text;state.textContent='Voice captured. Tap Ask when ready.'}};recognition.onerror=()=>{state.textContent='Voice input could not start. You can still type your question.'};recognition.onend=()=>{mic.classList.remove('listening');mic.textContent='🎙'};mic.onclick=()=>{try{recognition.start()}catch{}}}else{mic.onclick=()=>toast('Voice input is not available in this browser yet.')}
  const send=async()=>{
    const text=q.value.trim();if(!text)return toast('Type or speak a question first');
    const userMsg={role:'user',content:text};if(pendingImage)userMsg.imageDataUrl=pendingImage;
    history.push(userMsg);q.value='';render();state.textContent='Coach MW is thinking…';
    try{const token=mwSessionToken(),headers={'Content-Type':'application/json'};if(token)headers.Authorization='Bearer '+token;const r=await fetch('/api/coach/coach-mw',{method:'POST',headers,body:JSON.stringify({messages:history})});const d=await r.json();if(!r.ok)throw new Error(d.error||'Coach MW request failed');history.push({role:'assistant',content:d.answer||'I could not produce a response.'});history=history.slice(-40).map(m=>({role:m.role,content:m.content}));sessionStorage.setItem('mwCoachProConversation',JSON.stringify(history));pendingImage='';pick.value='';state.textContent='';render()}catch(e){state.textContent='Coach MW connection error: '+e.message}
  };
  document.getElementById('askmw').onclick=send;q.onkeydown=e=>{if(e.key==='Enter')send()};
}
function membershipPage(){
  if(!accountAccess.isFounder)return coachAccountPage();
  const p=PLANS[experience];
  app.innerHTML=`<div class="page ${p.theme}"><div class="page-wrap"><div class="page-top"><button class="back" id="back">← Dashboard</button><div style="flex:1"><div class="eyebrow">Founder Preview</div><h1>Preview Coach Tier</h1><div style="color:#adbdc8">Founder-only preview. Coach accounts cannot change their own access tier.</div></div></div><div class="plans">${Object.entries(PLANS).map(([k,v])=>`<div class="plan ${k===experience?'current':''}"><h2>${v.name}</h2><p>${v.sub}</p><p><b>$${v.monthly}/month</b><br><small>Sponsored athletes +$${v.sponsor}/athlete/month</small></p><button class="action" data-plan="${k}">${k===experience?'Current Preview':'Preview Tier'}</button></div>`).join('')}</div>${seasonCalendarSettingsHTML()}<section class="section coach-tour-account-card"><div><div class="eyebrow">GUIDED TOUR</div><h2>Learn ${escapeHtml(p.name)}</h2><p>Replay the full walkthrough for this coach platform anytime.</p></div><button class="action" id="replayCoachTour">Replay Tutorial</button></section></div></div>`;
  document.getElementById('back').onclick=dashboard;
  document.querySelectorAll('[data-plan]').forEach(b=>b.onclick=()=>smoothSwitchExperience(b.dataset.plan,b));
  document.getElementById('replayCoachTour').onclick=()=>startCoachTour({force:true,mode:'full'});
  bindSeasonCalendarSettings();
}
function coachAccountPage(){
  pageBase('Account','Your MW Coach access, billing, support, privacy, and account controls.',`<div class="tile"><h3>${escapeHtml(PLANS[experience].name)}</h3><p><b>$${PLANS[experience].monthly}/month</b> · Sponsored athletes <b>+$${PLANS[experience].sponsor}/athlete/month</b></p><p>Plan changes are protected: upgrades wait for payment confirmation; downgrades wait until the end of the paid period. Your current access stays live while the transition is pending.</p><small>MW Dynasty ${MW_APP_VERSION} · iOS Build ${MW_IOS_BUILD}</small></div><div class="tile" id="coachBillingPanel"><h3>Manage Coach Plan</h3><p>Loading secure billing status…</p></div>${experience!=='core'?coachMWSettingsHTML():''}${seasonCalendarSettingsHTML()}<div class="tile coach-tour-account-card"><div><h3>App Tutorial</h3><p>Replay the guided walkthrough for your current coach platform.</p></div><button class="action" id="replayCoachTour">Replay Tutorial</button></div><div class="tile"><h3>Privacy & Support</h3><p>Review the privacy policy, contact MW Support, or initiate account deletion.</p><div style="display:flex;gap:10px;flex-wrap:wrap"><button class="back" id="coachPrivacy">Privacy Policy</button><button class="back" id="coachSupport">Contact Support</button></div></div><div class="tile" style="border-color:#7a2c2c"><h3>Delete Coach Account</h3><p>Coach accounts can initiate deletion from inside MW Dynasty. Because coach accounts may be connected to team and athlete records, the request may require safe administrative cleanup before final removal.</p><button class="action" id="deleteCoachAccount" style="background:#7a2c2c">Delete Account</button><div id="deleteCoachState" style="margin-top:10px"></div></div>`);
  const replay=document.getElementById('replayCoachTour');if(replay)replay.onclick=()=>startCoachTour({force:true,mode:'full'});
  document.getElementById('coachPrivacy').onclick=()=>location.href='/privacy.html';
  document.getElementById('coachSupport').onclick=()=>supportPage();
  document.getElementById('deleteCoachAccount').onclick=requestCoachAccountDeletion;
  bindSeasonCalendarSettings();
  bindCoachBillingPanel();
  bindCoachMWSettings();
}
async function coachBillingRequest(method='GET',body=null){
  const token=mwSessionToken();if(!token)throw new Error('Coach session expired. Sign in again.');
  const r=await fetch('/api/billing',{method,headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json'},body:body?JSON.stringify(body):undefined});
  const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.error||'Billing request failed');return d;
}
function mwMoney(cents){const n=Number(cents||0);return new Intl.NumberFormat('en-US',{style:'currency',currency:'USD'}).format(n/100)}
function coachTierFromPlanCode(code){return code==='coach_core'?'core':code==='coach_intelligence'?'intelligence':code==='mw_sprint_performance'?'performance':experience}
async function bindCoachBillingPanel(){
  const panel=document.getElementById('coachBillingPanel');if(!panel)return;
  try{
    const d=await coachBillingRequest(),st=d.status||{},pending=st.pending_transition;
    panel.innerHTML=`<h3>Manage Coach Plan</h3><p><b>Current:</b> ${escapeHtml(PLANS[experience].name)}</p>${pending?`<div class="tile"><b>Plan change in progress</b><br><small>${escapeHtml(String(pending.direction||'change'))} · ${escapeHtml(String(pending.status||''))}${pending.effective_at?' · '+escapeHtml(fmtDate(pending.effective_at)):''}</small><br><small>Your current plan stays active until the transition is safely completed.</small></div>`:''}<div class="plans">${Object.entries(PLANS).map(([k,v])=>`<div class="plan ${k===experience?'current':''}"><h3>${escapeHtml(v.name)}</h3><p><b>$${v.monthly}/month</b><br><small>Sponsored athletes +$${v.sponsor}/athlete/month</small></p><button class="action coach-plan-change" data-tier="${k==='performance'?'mw_sprint_performance':k}" ${k===experience?'disabled':''}>${k===experience?'Current Plan':(PLANS[k].monthly>PLANS[experience].monthly?'Upgrade':'Downgrade')}</button></div>`).join('')}</div><p id="coachBillingState" style="margin-top:12px"><small>MW keeps the current entitlement active until billing confirms the next state. No mid-transition access gap.</small></p>`;
    panel.querySelectorAll('.coach-plan-change').forEach(btn=>btn.onclick=async()=>{const state=panel.querySelector('#coachBillingState');btn.disabled=true;const old=btn.textContent;btn.textContent='Preparing…';try{const out=await coachBillingRequest('POST',{action:'coach_plan_change',requestedTier:btn.dataset.tier}),r=out.result||{};state.innerHTML=r.direction==='upgrade'?`<b>Upgrade prepared.</b><br><small>Due now: <b>${mwMoney(Number(r.amount_due_now_cents||0))}</b>${Number(r.full_cycle_difference_cents||0)>Number(r.amount_due_now_cents||0)?` prorated from a ${mwMoney(Number(r.full_cycle_difference_cents||0))} full-cycle difference`:''}. You are never charged the full new plan twice. Your current plan stays active until payment confirms the upgrade.</small>`:`<b>Downgrade protected.</b><br><small>The lower tier will take effect at the end of the paid period${r.effective_at?' on '+escapeHtml(fmtDate(r.effective_at)):''}. Your current plan remains active until that handoff.</small>`;toast('Plan transition prepared')}catch(e){state.textContent=e.message}finally{btn.disabled=false;btn.textContent=old}});
  }catch(e){panel.innerHTML=`<h3>Manage Coach Plan</h3><p>${escapeHtml(e.message)}</p>`}
}
async function requestCoachAccountDeletion(){
  if(accountAccess.isFounder)return toast('Founder accounts must be transferred or removed through MW administration.');
  const typed=prompt('Delete your MW Dynasty coach account? If you have an Apple-billed subscription, deleting the MW account does NOT cancel Apple billing; manage that subscription separately. You may still initiate deletion now. Type DELETE to continue.');if(typed!=='DELETE')return;
  if(!confirm('Final confirmation: submit this coach account for deletion?'))return;
  const token=mwSessionToken(),btn=document.getElementById('deleteCoachAccount'),state=document.getElementById('deleteCoachState');
  if(!token){if(state)state.textContent='Sign in again before deleting your account.';return}
  if(btn){btn.disabled=true;btn.textContent='SUBMITTING…'}
  try{
    const r=await fetch(`${SUPABASE_URL}/functions/v1/mw-delete-account`,{method:'POST',headers:{apikey:SUPABASE_KEY,Authorization:`Bearer ${token}`,'Content-Type':'application/json'},body:'{}'});
    const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.error||'Account deletion request failed');
    if(state)state.innerHTML=d.deleted?'<b>Account deleted.</b>':'<b>Deletion request submitted.</b><br>Your request is recorded in MW Dynasty.';
    window.setTimeout(signOut,900);
  }catch(e){if(state)state.textContent=e.message||'Account deletion request failed.';if(btn){btn.disabled=false;btn.textContent='Delete Account'}}
}
function openPage(id){if(id!=='messages'&&window.__mwCoachMessagePoll){clearInterval(window.__mwCoachMessagePoll);window.__mwCoachMessagePoll=null}const routes={dashboard,athletes:athletesPage,teams:teamsPage,programs:programsPage,calendar:calendarPage,meets:meetsPage,attendance:attendancePage,messages:messagesPage,activity:activityPage,account:membershipPage,coachapps:coachApplicationsPage,support:supportPage,taskboard:taskBoardPage,season:seasonPage,adjustment:adjustmentPage,coachmw:coachMWPage,insights:insightsPage,mwtrack:mwTrackPage,strength:strengthPage,school:schoolPage,race:racePage,pacing:pacingPage,more:morePage};(routes[id]||supportPage)()}
function bindPageNavigation(root=document){
  root.querySelectorAll('[data-page]').forEach(b=>{if(b.dataset.mwBound==='1')return;b.dataset.mwBound='1';b.addEventListener('click',()=>openPage(b.dataset.page))});
  root.querySelectorAll('[data-stat]').forEach(b=>{if(b.dataset.mwStatBound==='1')return;b.dataset.mwStatBound='1';b.addEventListener('click',()=>{const m={'Athletes':'athletes','Teams':'teams','Upcoming Meets':'meets','Attendance':'attendance','Active Workouts':'programs','Week Program':'mwtrack','Pace Execution':'insights'};openPage(m[b.dataset.stat]||'dashboard')})});
}
async function coachSearchResults(query){
  const q=String(query||'').trim().toLowerCase();if(!q)return [];
  const navItems=[['athletes','Athletes','People you coach'],['teams','Teams','Groups and squads'],['calendar','Calendar','Practices and events'],['meets','Meets','Competition schedule'],['attendance','Attendance','Training attendance'],['messages','Messages','Coach communication'],['programs','Programs','Your training programs'],['activity','Activity Log','Recent coach activity'],['account','Account','Settings and training year'],['support','Help','Support and privacy']];
  if(experience!=='core')navItems.push(['insights','Performance Intelligence','Coach intelligence'],['coachmw','Coach MW AI','AI coaching assistant'],['taskboard','Task Board','Athlete priorities']);
  if(experience==='performance')navItems.push(['mwtrack','MW Training','41-week MW system'],['strength','Strength & Power','MW strength system'],['school','Sprint School','Education library'],['race','Race Strategy','Race planning'],['pacing','Pacing Tools','Training targets']);
  const results=navItems.filter(x=>(x[1]+' '+x[2]).toLowerCase().includes(q)).map(x=>({kind:'page',page:x[0],title:x[1],sub:x[2]}));
  try{
    const [roster,groups,programs,events]=await Promise.all([
      fetchCoachRoster().then(d=>d.athletes||[]).catch(()=>[]),
      sbRest('coach_groups?select=id,name,event_group&archived=eq.false&order=created_at.asc').catch(()=>[]),
      sbRest('coach_programs?select=id,name,program_type,status&order=updated_at.desc').catch(()=>[]),
      sbRest('coach_calendar_events?select=id,title,event_type,starts_at,location&order=starts_at.asc').catch(()=>[])
    ]);
    roster.filter(a=>`${a.name} ${a.event||''}`.toLowerCase().includes(q)).slice(0,5).forEach(a=>results.push({kind:'athlete',id:a.id,title:a.name,sub:a.event||'Athlete'}));
    groups.filter(g=>`${g.name} ${g.event_group||''}`.toLowerCase().includes(q)).slice(0,4).forEach(g=>results.push({kind:'group',id:g.id,title:g.name,sub:g.event_group||'Team / Group'}));
    programs.filter(x=>`${x.name} ${x.program_type||''}`.toLowerCase().includes(q)).slice(0,4).forEach(x=>results.push({kind:'program',id:x.id,title:x.name,sub:`${x.program_type||'program'} · ${x.status||'draft'}`}));
    events.filter(e=>`${e.title} ${e.location||''} ${e.event_type||''}`.toLowerCase().includes(q)).slice(0,4).forEach(e=>results.push({kind:'event',id:e.id,title:e.title,sub:`${e.event_type||'event'}${e.location?' · '+e.location:''}`}));
  }catch{}
  return results.slice(0,12);
}
function openCoachSearchResult(r){
  if(r.kind==='athlete')return athleteDetail(r.id);
  if(r.kind==='group')return groupWorkspaceLive(r.id);
  if(r.kind==='program')return programEditor(r.id);
  if(r.kind==='event')return calendarEventModal(r.id);
  openPage(r.page||'dashboard');
}
function bindCoachSearch(){
  const q=document.getElementById('dashSearch'),box=document.getElementById('dashSearchResults');if(!q||!box)return;let seq=0,last=[];
  const render=async()=>{const term=q.value.trim();const my=++seq;if(!term){box.hidden=true;box.innerHTML='';return}box.hidden=false;box.innerHTML='<div class="mw-search-loading">Searching MW Dynasty…</div>';const rows=await coachSearchResults(term);if(my!==seq)return;last=rows;box.innerHTML=rows.length?rows.map((r,i)=>`<button type="button" class="mw-search-result" data-search-i="${i}"><b>${escapeHtml(r.title)}</b><small>${escapeHtml(r.sub||'')}</small></button>`).join(''):'<div class="mw-search-loading">No matches found.</div>';box.querySelectorAll('[data-search-i]').forEach(b=>b.onclick=()=>{box.hidden=true;openCoachSearchResult(last[Number(b.dataset.searchI)])});};
  q.addEventListener('input',()=>{clearTimeout(q.__mwSearchTimer);q.__mwSearchTimer=setTimeout(render,180)});
  q.addEventListener('focus',()=>{if(q.value.trim())render()});
  q.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();if(last[0]){box.hidden=true;openCoachSearchResult(last[0])}else render()}if(e.key==='Escape')box.hidden=true});
  document.addEventListener('click',e=>{if(!e.target.closest('.mw-search-wrap'))box.hidden=true},{once:false});
}
async function fetchCoachNotifications(){
  const token=mwSessionToken();if(!token)throw new Error('Coach session expired. Sign in again.');
  const r=await fetch('/api/coach/notifications',{headers:{Authorization:`Bearer ${token}`},cache:'no-store'});const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.error||'Notifications unavailable.');return d;
}
async function hydrateNotificationBadge(){const badge=document.getElementById('notificationBadge');if(!badge)return;try{const d=await fetchCoachNotifications(),n=Number(d.unread||0);badge.textContent=n>99?'99+':String(n);badge.hidden=n===0}catch{badge.hidden=true}}
async function openNotifications(){
  const modal=mwModal('Notifications','<div id="notificationLive" class="list"><div class="tile">Loading notifications…</div></div><button class="back" id="markNotificationsRead" style="margin-top:12px">Mark All Read</button>');const wrap=modal.querySelector('#notificationLive');
  try{const d=await fetchCoachNotifications(),items=d.items||[];wrap.innerHTML=items.length?items.map(n=>`<button class="row mw-notification-row ${n.read_at?'':'unread'}" data-notification-id="${escapeHtml(n.id)}" data-notification-page="${escapeHtml(n.action_page||'dashboard')}" style="width:100%;text-align:left"><span><b>${escapeHtml(n.title)}</b><br><small>${escapeHtml(n.body)}</small></span><small>${new Date(n.created_at).toLocaleString()}</small></button>`).join(''):'<div class="tile"><h3>You’re all caught up</h3><p>No coach notifications yet.</p></div>';wrap.querySelectorAll('[data-notification-id]').forEach(b=>b.onclick=async()=>{try{await fetch('/api/coach/notifications',{method:'POST',headers:{Authorization:`Bearer ${mwSessionToken()}`,'Content-Type':'application/json'},body:JSON.stringify({action:'mark_read',id:b.dataset.notificationId})})}catch{}modal.remove();openPage(b.dataset.notificationPage||'dashboard')});}catch(e){wrap.innerHTML=`<div class="tile"><h3>Notifications unavailable</h3><p>${escapeHtml(e.message)}</p></div>`}
  const all=modal.querySelector('#markNotificationsRead');all.onclick=async()=>{all.disabled=true;try{await fetch('/api/coach/notifications',{method:'POST',headers:{Authorization:`Bearer ${mwSessionToken()}`,'Content-Type':'application/json'},body:JSON.stringify({action:'mark_all_read'})});await hydrateNotificationBadge();modal.remove()}finally{all.disabled=false}};
}
function bindGlobal(){const mm=document.getElementById('mobileMenu');const nav=document.getElementById('sideNav');if(mm&&nav){mm.addEventListener('click',()=>{const open=nav.classList.toggle('open');mm.setAttribute('aria-expanded',String(open));mm.textContent=open?'Close':'Menu';});}bindPageNavigation(document);const s=document.getElementById('signout');if(s)s.onclick=signOut;bindCoachSearch();const bell=document.getElementById('notificationBell');if(bell)bell.onclick=openNotifications;hydrateNotificationBadge();}
function bindPageActions(){document.querySelectorAll('[data-toast]').forEach(b=>b.onclick=()=>toast(b.dataset.toast))}
function toast(msg){let el=document.querySelector('.toast');if(!el){el=document.createElement('div');el.className='toast';document.body.appendChild(el)}el.textContent=msg;el.classList.add('show');clearTimeout(window.__mwToast);window.__mwToast=setTimeout(()=>el.classList.remove('show'),1600)}
function escapeHtml(s){return String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]))}
function smoothSwitchExperience(next,button){
  if(!PLANS[next]||next===experience){dashboard();return;}
  if(button){button.disabled=true;button.textContent='Opening…';}
  const current=document.querySelector('.app,.page');
  if(current)current.classList.add('experience-leaving');
  let veil=document.getElementById('experienceVeil');
  if(!veil){veil=document.createElement('div');veil.id='experienceVeil';veil.className='experience-veil';document.body.appendChild(veil);}
  const nextPlan=PLANS[next];
  veil.innerHTML=`<div class="experience-card ${nextPlan.theme}"><div class="experience-kicker">MW DYNASTY COACH</div><div class="experience-name">${nextPlan.title}</div><div class="experience-tag">${nextPlan.tag}</div><div class="experience-line"><span></span></div></div>`;
  requestAnimationFrame(()=>veil.classList.add('show'));
  window.setTimeout(()=>{
    experience=next;localStorage.setItem('mwCoachExperience',experience);dashboard();
    const fresh=document.querySelector('.app');if(fresh)fresh.classList.add('experience-entering');
    requestAnimationFrame(()=>{if(fresh)fresh.classList.add('experience-entered')});
    veil.classList.remove('show');
    window.setTimeout(()=>{veil.remove();if(fresh){fresh.classList.remove('experience-entering','experience-entered')}},520);
  },420);
}


/* ===== V2.6 COACH PLATFORM GUIDED TOURS ===== */
const COACH_TOUR_RANK={core:1,intelligence:2,performance:3};
const COACH_TOURS={
  core:[
    {icon:'✦',title:'Welcome to MW Coach Core',body:'Your command center for athletes, teams, programs, attendance, meets and communication.',hint:'A fast walkthrough of the tools you will use most.',target:null,label:'COACH CORE'},
    {icon:'📅',title:'Set the Training Year',body:'MW Standard Week 1 begins the day after Labor Day. Keep that standard calendar, or choose a Custom Season Start in Account when your team needs a different Week 1.',hint:'Assigned athletes inherit your coach calendar and placement. Independent athletes joining late use MW Smart Entry.',target:'.coach-training-year-card',label:'TRAINING YEAR'},
    {icon:'♟',title:'Manage Your Athletes',body:'Open the athlete roster to review profiles, assignments and the athletes connected to your coach account.',hint:'Athlete access stays scoped to the athletes you are authorized to coach.',target:'[data-page="athletes"]',label:'ATHLETES'},
    {icon:'✉',title:'Build Your Program',body:'Use Programs to create, save and manage your own coaching plan inside MW Dynasty.',hint:'Coach Core is built around your program and your coaching workflow.',target:'[data-page="programs"]',label:'PROGRAMS'},
    {icon:'✓',title:'Run the Day-to-Day',body:'Calendar, meets and attendance keep practices, competitions and participation organized in one place.',hint:'Your operational tools live together in the Coach navigation.',target:'[data-page="attendance"]',label:'ATTENDANCE'},
    {icon:'💬',title:'Stay Connected',body:'Use Messages to communicate with your athletes and keep important follow-up inside the platform.',hint:'Coach communication stays attached to the coaching workspace.',target:'[data-page="messages"]',label:'MESSAGES'},
    {icon:'⚙',title:'You’re Ready to Coach',body:'Your Account shows your assigned MW Coach tier. You can replay this tutorial there anytime.',hint:'MW Dynasty controls coach access; coaches cannot change their own tier.',target:'[data-page="account"]',label:'ACCOUNT'}
  ],
  intelligence:[
    {icon:'✦',title:'Welcome to MW Coach Intelligence',body:'Your coaching program stays yours — MW Intelligence adds roster monitoring, AI priorities and decision support.',hint:'AI detects and recommends. You remain the coach in control.',target:null,label:'COACH INTELLIGENCE'},
    {icon:'📅',title:'Your Team’s Training Calendar',body:'MW Standard Week 1 begins the day after Labor Day, or you can set a Custom Season Start. That calendar becomes the reference for roster monitoring and season intelligence.',hint:'Coach-assigned athletes follow your calendar and placement; independent late joiners use Smart Entry.',target:'.coach-training-year-card',label:'TRAINING YEAR'},
    {icon:'◉',title:'Know Who Needs You',body:'The Athlete Status Board separates your roster into On Track, Watch and Needs Attention, with the reason for every flag.',hint:'Start here when you need to know where your attention matters most.',target:'.athlete-status-section',label:'ATHLETE STATUS'},
    {icon:'☑',title:'AI Task Board',body:'MW turns roster signals into a prioritized coaching task list so important follow-up does not get buried.',hint:'Review the recommendation before taking action.',target:'[data-page="taskboard"]',label:'AI TASK BOARD'},
    {icon:'▣',title:'Plan the Season',body:'AI Season Planner helps organize your season around your own program, competition calendar and athlete needs.',hint:'Use it to support your plan — not replace your coaching judgment.',target:'[data-page="season"]',label:'SEASON PLANNER'},
    {icon:'☻',title:'Coach MW AI',body:'Ask Coach MW questions about athletes, workload, planning and MW coaching intelligence from one assistant.',hint:'Coach MW recommends. You approve before execution.',target:'[data-page="coachmw"]',label:'COACH MW AI'},
    {icon:'▱',title:'See the Signals',body:'AI Insights summarizes workload, PR coverage, training recency and other roster-level signals for faster review.',hint:'Use the insight as a reason to inspect the supporting athlete data.',target:'[data-page="insights"]',label:'AI INSIGHTS'},
    {icon:'⚙',title:'Intelligence Is Ready',body:'Your Account shows your assigned platform, and the complete tutorial can be replayed whenever you need it.',hint:'You stay in control of every coaching decision.',target:'[data-page="account"]',label:'ACCOUNT'}
  ],
  performance:[
    {icon:'✦',title:'Welcome to MW Sprint Performance',body:'This is the complete MW ecosystem: the 41-week sprint system, strength, education, pacing and full Coach Intelligence.',hint:'The system has the plan. Technology helps you execute it.',target:null,label:'SPRINT PERFORMANCE'},
    {icon:'📅',title:'The 41-Week Training Year',body:'The standard MW cycle begins the day after Labor Day and progresses through all 41 weeks. Coaches can set a Custom Week 1 when their team calendar requires it.',hint:'Assigned athletes inherit the coach calendar and placement. Late independent athletes use Smart Entry so track + strength begin at a prepared point.',target:'.coach-training-year-card',label:'TRAINING YEAR'},
    {icon:'◉',title:'Start With Athlete Status',body:'See who is On Track, who needs to be watched and who needs immediate coaching attention — with the reason for each flag.',hint:'Roster intelligence is built into the complete performance system.',target:'.athlete-status-section',label:'ATHLETE STATUS'},
    {icon:'🏃',title:'The 41-Week MW Track Program',body:'Open the protected MW Track Program to see the exact progressive sprint prescription, recovery, cues and circuit order.',hint:'This is the sprint-program backbone of MW Dynasty.',target:'[data-page="mwtrack"]',label:'MW TRACK PROGRAM'},
    {icon:'🏋',title:'Strength & Power',body:'The weight-room plan is synchronized with the sprint system so loading and progression support the track work.',hint:'Track and strength are designed to work as one progression.',target:'[data-page="strength"]',label:'STRENGTH & POWER'},
    {icon:'◷',title:'Individualize the Pace',body:'Pacing Tools use athlete PR data to calculate individualized target times for training reps.',hint:'Better targets help athletes execute the prescribed intent of the session.',target:'[data-page="pacing"]',label:'PACING TOOLS'},
    {icon:'☻',title:'Coach MW AI',body:'Coach MW connects the MW system, your roster and coaching intelligence so you can ask questions in context.',hint:'Detect → Analyze → Recommend → Coach Approves → Execute.',target:'[data-page="coachmw"]',label:'COACH MW AI'},
    {icon:'⚙',title:'The Complete System Is Ready',body:'Use your Account to confirm your platform access and replay this walkthrough whenever you want a refresher.',hint:'MW Sprint Performance keeps the methodology, tools and athlete intelligence in one coach workspace.',target:'[data-page="account"]',label:'ACCOUNT'}
  ]
};
const COACH_UPGRADE_TOURS={
  intelligence:[
    {icon:'⚡',title:'Coach Intelligence Is Unlocked',body:'Your platform now adds live roster intelligence and AI decision support on top of your coaching workflow.',hint:'Here are the biggest new tools.',target:null,label:'WHAT’S NEW'},
    {icon:'◉',title:'Athlete Status Board',body:'Your roster is now organized into On Track, Watch and Needs Attention so you can prioritize faster.',hint:'Every flag includes the reason MW detected it.',target:'.athlete-status-section',label:'NEW · ATHLETE STATUS'},
    {icon:'☑',title:'AI Priorities',body:'The AI Task Board turns athlete signals into daily coaching priorities for you to review.',hint:'You decide what gets approved and acted on.',target:'[data-page="taskboard"]',label:'NEW · AI TASK BOARD'},
    {icon:'☻',title:'Coach MW + Insights',body:'Coach MW AI and AI Insights give you deeper context without taking control away from the coach.',hint:'Your upgraded platform is ready.',target:'[data-page="coachmw"]',label:'NEW · COACH MW'}
  ],
  performance:[
    {icon:'⚡',title:'MW Sprint Performance Is Unlocked',body:'You now have the complete MW system plus the full Coach Intelligence layer.',hint:'Here are the major tools added with this platform.',target:null,label:'WHAT’S NEW'},
    {icon:'🏃',title:'41-Week Track System',body:'The complete progressive MW Track Program is now available. Standard Week 1 begins the day after Labor Day, or your team can use a coach-controlled Custom Season Start.',hint:'Athletes do not freely jump weeks: coached athletes follow coach placement; independent late joiners use Smart Entry.',target:'[data-page="mwtrack"]',label:'NEW · TRACK PROGRAM'},
    {icon:'🏋',title:'Strength & Power',body:'The synchronized MW weight-room progression is now connected to the sprint program.',hint:'Track and strength now live together.',target:'[data-page="strength"]',label:'NEW · STRENGTH'},
    {icon:'▤',title:'Sprint School + Race Strategy',body:'Technique education, starts, race strategy and execution resources are now part of your platform.',hint:'Teach the athlete as well as train the athlete.',target:'[data-page="school"]',label:'NEW · SPRINT SCHOOL'},
    {icon:'◷',title:'Pacing Tools',body:'Use live athlete PRs to calculate individualized target times for the prescribed work.',hint:'The complete performance platform is ready.',target:'[data-page="pacing"]',label:'NEW · PACING'}
  ]
};
let coachTourState=null;
function coachTourUserKey(){return String(authSession?.user?.id||readStoredSession()?.user?.id||'local')}
function coachTourCompleteKey(tier=experience){return `mwCoachTourComplete:${coachTourUserKey()}:${tier}:v26`}
function coachTourLastTierKey(){return `mwCoachLastTier:${coachTourUserKey()}`}
function coachTourRank(t){return COACH_TOUR_RANK[t]||0}
function maybeStartCoachTour(){
  if(document.getElementById('coachTour'))return;
  const uid=coachTourUserKey();if(uid==='local')return;
  if(accountAccess.isFounder){
    if(localStorage.getItem(coachTourCompleteKey(experience))!=='1')startCoachTour({mode:'full'});
    return;
  }
  const last=localStorage.getItem(coachTourLastTierKey())||'';
  const current=experience;
  if(last&&coachTourRank(current)>coachTourRank(last)&&COACH_UPGRADE_TOURS[current]){
    startCoachTour({mode:'upgrade'});return;
  }
  if(localStorage.getItem(coachTourCompleteKey(current))!=='1')startCoachTour({mode:'full'});
  else localStorage.setItem(coachTourLastTierKey(),current);
}
function coachTourEnsureDashboard(){
  if(!document.querySelector('.app'))dashboard();
}
function coachTourOpenNavIfNeeded(step){
  const navEl=document.getElementById('sideNav'),menu=document.getElementById('mobileMenu');
  if(!navEl||!menu)return;
  if(step?.target?.startsWith('[data-page=')&&window.matchMedia('(max-width:820px)').matches){navEl.classList.add('open');menu.setAttribute('aria-expanded','true');menu.textContent='Close';}
}
function coachTourCloseNav(){const navEl=document.getElementById('sideNav'),menu=document.getElementById('mobileMenu');if(navEl&&menu&&window.matchMedia('(max-width:820px)').matches){navEl.classList.remove('open');menu.setAttribute('aria-expanded','false');menu.textContent='Menu';}}
function startCoachTour(opts={}){
  const mode=opts.mode||'full';
  if(opts.force){document.getElementById('coachTour')?.remove();coachTourEnsureDashboard();}
  const steps=mode==='upgrade'?(COACH_UPGRADE_TOURS[experience]||COACH_TOURS[experience]):COACH_TOURS[experience];
  if(!steps?.length)return;
  if(!document.querySelector('.app')){dashboard();window.setTimeout(()=>startCoachTour(opts),220);return;}
  document.getElementById('coachTour')?.remove();
  const root=document.createElement('div');root.id='coachTour';root.className=`coach-tour ${PLANS[experience].theme} ${mode==='upgrade'?'upgrade':''}`;
  root.innerHTML=`<div class="coach-tour-spotlight" id="coachTourSpotlight"></div><div class="coach-tour-tag" id="coachTourTag"></div><section class="coach-tour-card" id="coachTourCard" role="dialog" aria-modal="true" aria-label="${escapeHtml(PLANS[experience].name)} tutorial"><div class="coach-tour-top"><div class="coach-tour-kicker">MW DYNASTY · ${mode==='upgrade'?'WHAT’S NEW':'GUIDED TOUR'}</div><div class="coach-tour-step" id="coachTourStep"></div></div><div class="coach-tour-lead"><div class="coach-tour-icon" id="coachTourIcon"></div><div><h2 id="coachTourTitle"></h2><p id="coachTourBody"></p></div></div><div class="coach-tour-hint" id="coachTourHint"></div><div class="coach-tour-dots" id="coachTourDots"></div><div class="coach-tour-actions"><button type="button" class="coach-tour-skip" id="coachTourSkip">SKIP</button><button type="button" class="coach-tour-back" id="coachTourBack">BACK</button><button type="button" class="coach-tour-next" id="coachTourNext">NEXT</button></div></section>`;
  document.body.appendChild(root);
  coachTourState={mode,steps,index:0,root};
  root.querySelector('#coachTourSkip').onclick=()=>finishCoachTour(true);
  root.querySelector('#coachTourBack').onclick=()=>{if(coachTourState.index>0){coachTourState.index--;renderCoachTourStep()}};
  root.querySelector('#coachTourNext').onclick=()=>{if(coachTourState.index>=steps.length-1)finishCoachTour(false);else{coachTourState.index++;renderCoachTourStep()}};
  window.addEventListener('resize',coachTourReposition,{passive:true});
  renderCoachTourStep();
}
function renderCoachTourStep(){
  const st=coachTourState;if(!st)return;const step=st.steps[st.index],root=st.root;
  coachTourOpenNavIfNeeded(step);
  root.querySelector('#coachTourStep').textContent=`${st.index+1} OF ${st.steps.length}`;
  root.querySelector('#coachTourIcon').textContent=step.icon||'✦';
  root.querySelector('#coachTourTitle').textContent=step.title;
  root.querySelector('#coachTourBody').textContent=step.body;
  root.querySelector('#coachTourHint').textContent=step.hint||'';
  root.querySelector('#coachTourBack').disabled=st.index===0;
  root.querySelector('#coachTourNext').textContent=st.index===st.steps.length-1?'FINISH':'NEXT';
  root.querySelector('#coachTourDots').innerHTML=st.steps.map((_,i)=>`<i class="${i===st.index?'active':''}"></i>`).join('');
  root.classList.toggle('no-target',!step.target);
  window.setTimeout(()=>coachTourPosition(step),60);
}
function coachTourPosition(step){
  const root=coachTourState?.root;if(!root)return;const spot=root.querySelector('#coachTourSpotlight'),tag=root.querySelector('#coachTourTag'),card=root.querySelector('#coachTourCard');
  if(!step.target){spot.style.display='none';tag.style.display='none';card.classList.remove('at-top');return;}
  const target=document.querySelector(step.target);if(!target){spot.style.display='none';tag.style.display='none';return;}
  target.scrollIntoView({block:'nearest',inline:'nearest'});
  const r=target.getBoundingClientRect(),pad=7;
  const left=Math.max(8,r.left-pad),top=Math.max(8,r.top-pad),width=Math.min(window.innerWidth-left-8,r.width+pad*2),height=Math.min(window.innerHeight-top-8,r.height+pad*2);
  spot.style.display='block';spot.style.left=`${left}px`;spot.style.top=`${top}px`;spot.style.width=`${Math.max(38,width)}px`;spot.style.height=`${Math.max(34,height)}px`;
  tag.style.display='block';tag.textContent=step.label||'';tag.style.left=`${Math.max(10,Math.min(left,window.innerWidth-150))}px`;tag.style.top=`${Math.max(8,top-30)}px`;
  card.classList.toggle('at-top',r.top>window.innerHeight*.52);
}
function coachTourReposition(){const st=coachTourState;if(st)coachTourPosition(st.steps[st.index])}
function finishCoachTour(skipped=false){
  const st=coachTourState;if(!st)return;
  localStorage.setItem(coachTourCompleteKey(experience),'1');
  if(!accountAccess.isFounder)localStorage.setItem(coachTourLastTierKey(),experience);
  window.removeEventListener('resize',coachTourReposition);
  st.root?.remove();coachTourState=null;coachTourCloseNav();
  toast(skipped?'Tutorial skipped — replay it from Account anytime.':'Tutorial complete — you’re ready to coach.');
}

function renderLogin(message=''){
  app.innerHTML=`<div class="coach-login-screen">
    <section class="coach-login-stage" aria-label="MW Coach sign in">
      <div class="coach-login-bg" aria-hidden="true"></div>
      <header class="coach-login-header">
        <div class="coach-login-brand" aria-label="MW Coach">
          <div class="coach-login-mw">MW</div>
          <div class="coach-login-coach">DYNASTY</div>
          <div class="coach-login-tagline">COACH LOGIN • LEAD • DEVELOP • BUILD</div>
        </div>
        <nav class="coach-login-nav" aria-label="MW Coach values">
          <span>DISCIPLINE</span><i></i><span>DEVELOPMENT</span><i></i><span>DOMINANCE</span><i></i><span>RESOURCES</span>
        </nav>
        <div class="coach-login-mission">COACHES TODAY<br>STRONGER ATHLETES<br>BRIGHTER TOMORROW<div></div></div>
      </header>

      <div class="coach-login-content">
        <div class="coach-login-copy">
          <h1>COACH<br>DEVELOP<br>EMPOWER<br><strong>TRANSFORM</strong></h1>
          <span class="coach-login-rule"></span>
          <p>MORE THAN A PLATFORM.<br>A HIGHER STANDARD.</p>
        </div>

        <div class="coach-login-person" role="img" aria-label="Coach standing trackside"></div>

        <div class="coach-login-card-wrap">
          <div class="coach-login-card">
            <div class="coach-login-mobile-brand" aria-hidden="true"><span>MW</span> DYNASTY · COACH</div>
            <h2>Welcome Back</h2>
            <p>Sign in to your MW Dynasty Coach experience.</p>
            <form id="loginForm" class="coach-login-form" novalidate>
              <label class="coach-field">
                <span aria-hidden="true">✉</span>
                <input id="loginEmail" type="email" autocomplete="email" inputmode="email" placeholder="Enter your email" required>
              </label>
              <label class="coach-field">
                <span aria-hidden="true">▣</span>
                <input id="loginPassword" type="password" autocomplete="current-password" placeholder="Enter your password" required>
                <button id="togglePassword" type="button" class="coach-password-toggle" aria-label="Show password">◉</button>
              </label>
              <div class="coach-login-options">
                <label class="coach-remember"><input id="rememberMe" type="checkbox" checked><span>Keep me signed in</span></label>
                <button id="forgotPassword" type="button" class="coach-forgot">Forgot password?</button>
              </div>
              <div id="loginMessage" class="login-message ${message?'show':''}" role="status" aria-live="polite">${escapeHtml(message)}</div>
              <button id="loginSubmit" class="coach-login-submit" type="submit"><span>Sign In</span><span aria-hidden="true">→</span></button>
            </form>
            <div class="coach-login-divider"><span></span><b>NEW COACH?</b><span></span></div>
            <div class="coach-login-contact">Don’t have a coach account yet? <button type="button" id="contactAdmin">Create an Account</button></div>
          </div>
        </div>
      </div>

      <div class="coach-login-features" aria-label="MW Coach capabilities">
        <div><b>♟</b><span>MANAGE<br>ATHLETES</span></div>
        <div><b>▥</b><span>TRACK<br>PROGRESS</span></div>
        <div><b>▣</b><span>PLAN<br>SEASONS</span></div>
        <div><b>◉</b><span>AI<br>COACHING</span></div>
        <div><b>🏆</b><span>BUILD<br>CHAMPIONS</span></div>
      </div>
    </section>
  </div>`;
  bindLogin();
  const contact=document.getElementById('contactAdmin');
  if(contact)contact.addEventListener('click',renderCoachApplication);
}
function renderCoachApplication(){
  const existing=document.getElementById('coachApplyModal');if(existing)existing.remove();
  const wrap=document.createElement('div');wrap.id='coachApplyModal';wrap.className='coach-apply-modal';
  wrap.innerHTML=`<div class="coach-apply-backdrop" data-close="1"></div><section class="coach-apply-card" role="dialog" aria-modal="true" aria-labelledby="coachApplyTitle">
    <div class="coach-apply-head"><div><div class="coach-apply-kicker">MW DYNASTY</div><h2 id="coachApplyTitle">Create Your Coach Account</h2><p>Start your coach signup here. Coach access is reviewed before it is activated.</p></div><button type="button" class="coach-apply-close" data-close="1" aria-label="Close">×</button></div>
    <form id="coachApplyForm" class="coach-apply-form">
      <div class="coach-apply-two"><label>First name<input id="applyFirst" required maxlength="80"></label><label>Last name<input id="applyLast" required maxlength="80"></label></div>
      <label>Email<input id="applyEmail" type="email" required maxlength="320" autocomplete="email"></label>
      <label>School / club / organization<input id="applyOrg" maxlength="160" placeholder="Optional"></label>
      <div class="coach-apply-two"><label>City<input id="applyCity" maxlength="100"></label><label>State<input id="applyState" maxlength="80"></label></div>
      <div class="coach-apply-two"><label>Coaching level<select id="applyLevel"><option value="">Select</option><option>High School</option><option>College</option><option>Club / AAU</option><option>Private Coach</option><option>Middle School</option><option>Other</option></select></label><label>Years coaching<input id="applyYears" type="number" min="0" max="80" inputmode="numeric"></label></div>
      <label>Website or social profile<input id="applySocial" maxlength="300" placeholder="Optional"></label>
      <label>Why are you requesting MW Coach access?<textarea id="applyReason" rows="5" minlength="20" maxlength="2000" required placeholder="Tell us about who you coach and how you plan to use the platform."></textarea></label>
      <div id="coachApplyMessage" class="login-message" role="status" aria-live="polite"></div>
      <button id="coachApplySubmit" class="coach-login-submit" type="submit"><span>Continue Coach Signup</span><span>→</span></button>
    </form>
    <p class="coach-apply-foot">After review and approval, MW Dynasty will activate your coach access and send the next account-setup step.</p>
  </section>`;
  document.body.appendChild(wrap);
  wrap.querySelectorAll('[data-close="1"]').forEach(x=>x.addEventListener('click',()=>wrap.remove()));
  document.getElementById('coachApplyForm').addEventListener('submit',submitCoachApplication);
}
async function submitCoachApplication(e){
  e.preventDefault();const b=document.getElementById('coachApplySubmit'),m=document.getElementById('coachApplyMessage');
  const payload={first_name:document.getElementById('applyFirst').value.trim(),last_name:document.getElementById('applyLast').value.trim(),email:document.getElementById('applyEmail').value.trim(),organization:document.getElementById('applyOrg').value.trim(),city:document.getElementById('applyCity').value.trim(),state:document.getElementById('applyState').value.trim(),coaching_level:document.getElementById('applyLevel').value,years_coaching:document.getElementById('applyYears').value||null,website_or_social:document.getElementById('applySocial').value.trim(),reason:document.getElementById('applyReason').value.trim()};
  if(payload.reason.length<20){m.textContent='Please tell us a little more about your coaching background and intended use.';m.className='login-message show error';return}
  b.disabled=true;b.innerHTML='<span class="login-spinner"></span><span>Submitting…</span>';m.textContent='Submitting for review…';m.className='login-message show neutral';
  try{const r=await fetch(`${SUPABASE_URL}/functions/v1/mw-coach-apply`,{method:'POST',headers:{apikey:SUPABASE_KEY,'Content-Type':'application/json'},body:JSON.stringify(payload)});const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.error||'Application could not be submitted.');m.textContent=d.message||'Application received. MW Dynasty will review your request.';m.className='login-message show success';b.innerHTML='<span>Application Submitted ✓</span>';window.setTimeout(()=>document.getElementById('coachApplyModal')?.remove(),2400)}catch(err){m.textContent=err.message;m.className='login-message show error';b.disabled=false;b.innerHTML='<span>Continue Coach Signup</span><span>→</span>'}
}
async function verifyCoachAccess(session){
  const r=await fetch('/api/coach/access',{headers:{Authorization:`Bearer ${session.access_token}`}});const d=await r.json().catch(()=>({}));
  if(!r.ok)throw new Error(r.status===403?'This login is not an approved, active MW Coach account.':(d.error||'Coach access could not be verified.'));
  accountAccess={role:d.role||null,tier:d.tier||null,isFounder:!!d.isFounder};
  if(accountAccess.isFounder){experience='performance';return d;}
  const map={core:'core',intelligence:'intelligence',mw_sprint_performance:'performance'};
  if(!map[d.tier])throw new Error('This coach account does not have an active MW Coach tier.');
  experience=map[d.tier];
  return d;
}
function setLoginMessage(text,type='error'){
  const el=document.getElementById('loginMessage');if(!el)return;el.textContent=text;el.className=`login-message show ${type}`;
}
function setLoginBusy(busy){
  const b=document.getElementById('loginSubmit');if(!b)return;b.disabled=busy;b.innerHTML=busy?'<span class="login-spinner" aria-hidden="true"></span><span>Signing In…</span>':'<span>Sign In</span><span aria-hidden="true">→</span>';
}
async function supabasePasswordLogin(email,password){
  const r=await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=password`,{method:'POST',headers:{apikey:SUPABASE_KEY,'Content-Type':'application/json'},body:JSON.stringify({email,password})});
  const data=await r.json().catch(()=>({}));
  if(!r.ok)throw new Error(data.error_description||data.msg||data.message||'Unable to sign in. Check your email and password.');
  return data;
}
async function validateSession(session){
  if(!session?.access_token)return false;
  const r=await fetch(`${SUPABASE_URL}/auth/v1/user`,{headers:{apikey:SUPABASE_KEY,Authorization:`Bearer ${session.access_token}`}});
  return r.ok;
}
function persistSession(session,remember=true){
  authSession=session;
  if(remember)localStorage.setItem(SESSION_KEY,JSON.stringify(session));else sessionStorage.setItem(SESSION_KEY,JSON.stringify(session));
}
function clearSession(){authSession=null;localStorage.removeItem(SESSION_KEY);sessionStorage.removeItem(SESSION_KEY)}
function readStoredSession(){
  try{return JSON.parse(localStorage.getItem(SESSION_KEY)||sessionStorage.getItem(SESSION_KEY)||'null')}catch{return null}
}
async function signOut(){
  const token=authSession?.access_token;
  clearSession();
  if(token){try{await fetch(`${SUPABASE_URL}/auth/v1/logout`,{method:'POST',headers:{apikey:SUPABASE_KEY,Authorization:`Bearer ${token}`}})}catch{}}
  renderLogin('You have been signed out.');
}
function bindLogin(){
  const form=document.getElementById('loginForm'),pass=document.getElementById('loginPassword'),toggle=document.getElementById('togglePassword'),forgot=document.getElementById('forgotPassword');
  toggle.addEventListener('click',()=>{const show=pass.type==='password';pass.type=show?'text':'password';toggle.textContent=show?'Hide':'Show';toggle.setAttribute('aria-label',show?'Hide password':'Show password')});
  forgot.addEventListener('click',async()=>{
    const email=document.getElementById('loginEmail').value.trim();
    if(!email)return setLoginMessage('Enter your email address first, then tap Forgot password.');
    forgot.disabled=true;forgot.textContent='Sending…';
    try{const r=await fetch(`${SUPABASE_URL}/auth/v1/recover`,{method:'POST',headers:{apikey:SUPABASE_KEY,'Content-Type':'application/json'},body:JSON.stringify({email})});if(!r.ok){const d=await r.json().catch(()=>({}));throw new Error(d.msg||d.message||'Unable to send reset email.')}setLoginMessage('Password reset email sent. Check your inbox.','success')}catch(e){setLoginMessage(e.message)}finally{forgot.disabled=false;forgot.textContent='Forgot password?'}
  });
  form.addEventListener('submit',async e=>{
    e.preventDefault();
    const email=document.getElementById('loginEmail').value.trim(),password=pass.value,remember=document.getElementById('rememberMe').checked;
    if(!email||!password)return setLoginMessage('Enter both your email address and password.');
    setLoginBusy(true);setLoginMessage('Signing you in…','neutral');
    try{const session=await supabasePasswordLogin(email,password);await verifyCoachAccess(session);persistSession(session,remember);dashboard()}catch(err){clearSession();setLoginMessage(err.message)}finally{setLoginBusy(false)}
  });
}
async function initAuth(){
  await loadPricingCatalog();
  const stored=readStoredSession();
  if(stored){
    authSession=stored;
    try{if(await validateSession(stored)){await verifyCoachAccess(stored);dashboard();return}}catch{}
    clearSession();
  }
  renderLogin();
  const params=new URLSearchParams(location.search);
  if(params.get('apply')==='1'){setTimeout(()=>renderCoachApplication(),50);}
}


/* ===== V11.21 FULL INTERACTIVE INTERFACES ===== */
function mwSessionToken(){return authSession?.access_token||readStoredSession()?.access_token||''}
async function mwCurrentUser(){
  if(authSession?.user?.id)return authSession.user;
  const token=mwSessionToken(); if(!token)return null;
  const r=await fetch(`${SUPABASE_URL}/auth/v1/user`,{headers:{apikey:SUPABASE_KEY,Authorization:`Bearer ${token}`}});
  if(!r.ok)return null; return await r.json();
}
function mwModal(title,body){
  document.getElementById('mwModal')?.remove();
  const el=document.createElement('div');el.id='mwModal';el.className=`mw-modal ${PLANS[experience].theme}`;
  el.innerHTML=`<div class="mw-modal-backdrop" data-close-modal></div><section class="mw-modal-card" role="dialog" aria-modal="true" aria-label="${escapeHtml(title)}"><div class="mw-modal-head"><div><div class="eyebrow">${PLANS[experience].name}</div><h2>${escapeHtml(title)}</h2></div><button class="back" type="button" data-close-modal>✕</button></div><div class="mw-modal-body">${body}</div></section>`;
  document.body.appendChild(el);el.querySelectorAll('[data-close-modal]').forEach(x=>x.onclick=()=>el.remove());return el;
}
function mwStore(key,value){localStorage.setItem('mwCoach:'+key,JSON.stringify(value))}
function mwLoad(key,fallback){try{return JSON.parse(localStorage.getItem('mwCoach:'+key)||'null')??fallback}catch{return fallback}}
async function fetchCoachRoster(){
  const token=mwSessionToken();if(!token)throw new Error('Coach session expired. Sign in again.');
  const r=await fetch('/api/coach/roster',{headers:{Authorization:`Bearer ${token}`}});
  const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.error||'Roster could not be loaded.');return d;
}
async function fetchCoachPerformance(athleteId=''){
  const token=mwSessionToken();if(!token)throw new Error('Coach session expired. Sign in again.');
  const qs=athleteId?`?athleteId=${encodeURIComponent(athleteId)}`:'';
  const r=await fetch('/api/coach/performance'+qs,{headers:{Authorization:`Bearer ${token}`},cache:'no-store'});
  const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.error||'Performance intelligence could not be loaded.');return d;
}
async function hydrateLivePerformanceSummary(){
  const stat=document.querySelector('[data-stat="Pace Execution"] b');if(!stat)return;
  try{const d=await fetchCoachPerformance();if(d.rep_tracking_enabled===false){stat.textContent='MW ONLY';return}const v=d.summary?.average_latest_execution_pct;stat.textContent=v==null?'—':`${v}%`}catch{stat.textContent='—'}
}
async function hydratePerformanceInsightPreview(){
  const el=document.getElementById('performanceInsightPreview');if(!el)return;
  try{const d=await fetchCoachPerformance();if(d.rep_tracking_enabled===false){el.innerHTML='<div class="insight"><span class="insight-symbol" style="color:#e3b51d">★</span><div><h4>Rep Tracking — MW System Exclusive</h4><p>Rep-by-rep sprint execution is reserved for the MW Sprint Performance System. Coach Intelligence still supports your coaching workflow without exposing MW rep tracking.</p></div><span>PREMIUM</span></div>';return}const a=d.athletes||[],s=d.summary||{},flagged=a.filter(x=>(x.flags||[]).length).sort((x,y)=>((y.flags||[]).some(f=>f.level==='attention')?2:1)-((x.flags||[]).some(f=>f.level==='attention')?2:1)),first=flagged[0];
    const cards=[`<div class="insight"><span class="insight-symbol" style="color:#159bff">◷</span><div><h4>Pace Execution</h4><p>${s.average_latest_execution_pct!=null?`${s.average_latest_execution_pct}% average across latest check-ins.`:'No pace check-ins recorded yet.'}</p></div><span>LIVE</span></div>`,`<div class="insight"><span class="insight-symbol" style="color:#e3b51d">!</span><div><h4>Coach Review</h4><p>${s.review_flags||0} review flag${Number(s.review_flags||0)===1?'':'s'} · ${s.watch_flags||0} watch flag${Number(s.watch_flags||0)===1?'':'s'}.</p></div><span>LIVE</span></div>`];
    if(first){const roster=await fetchCoachRoster(),name=(roster.athletes||[]).find(x=>x.id===first.athlete_id)?.name||'Athlete',msg=first.flags?.[0]?.message||'Performance trend worth review';cards.push(`<div class="insight"><span class="insight-symbol" style="color:#ff8d66">↗</span><div><h4>${escapeHtml(name)}</h4><p>${escapeHtml(msg)}</p></div><span>REVIEW</span></div>`)}
    el.innerHTML=cards.join('');
  }catch(e){el.innerHTML=`<div class="tile"><h3>Performance intelligence unavailable</h3><p>${escapeHtml(e.message)}</p></div>`}
}
async function hydrateLiveAthleteCount(){
  const stat=document.querySelector('[data-stat="Athletes"] b');if(!stat)return;
  try{const d=await fetchCoachRoster();stat.textContent=String(d.count??d.athletes?.length??0)}catch{}
}
function fmtDate(v){if(!v)return '—';try{return new Date(v).toLocaleDateString()}catch{return '—'}}
async function athleteDetail(athleteId){
  const modal=mwModal('Athlete Profile',`<div id="athleteDetailState" class="tile">Loading live athlete record…</div>`);
  const state=modal.querySelector('#athleteDetailState');
  try{
    const token=mwSessionToken();if(!token)throw new Error('Coach session expired. Sign in again.');
    const [r,perfD]=await Promise.all([fetch(`/api/coach/athlete?id=${encodeURIComponent(athleteId)}`,{headers:{Authorization:`Bearer ${token}`}}),fetchCoachPerformance(athleteId).catch(()=>({athlete:null}))]);
    const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.error||'Athlete record could not be loaded.');
    const a=d.athlete||{},prs=Array.isArray(a.prs)?a.prs:[],notes=Array.isArray(a.notes)?a.notes:[],assignedCheckins=Array.isArray(a.assigned_training_checkins)?a.assigned_training_checkins:[],perf=perfD.athlete||null,repTrackingEnabled=perfD.rep_tracking_enabled!==false;
    modal.querySelector('.mw-modal-head h2').textContent=a.name||'Athlete Profile';
    state.outerHTML=`<div id="athleteDetailLive">
      <div class="panel-grid">
        <div class="tile"><h3>Events</h3><p>${escapeHtml(a.event||'Events not set')}</p><small>${a.track_training_years!=null?escapeHtml(String(a.track_training_years))+' years consistent training':escapeHtml(a.experience_level||'Experience level not set')}</small></div>
        <div class="tile"><h3>Program</h3><p><b>Week ${Number(a.current_week||1)} · Day ${Number(a.current_day||1)}</b></p><small>${escapeHtml(String(a.program_status||'On Track'))}</small></div>
        <div class="tile"><h3>Track Tier</h3><p><b>${escapeHtml(String(a.track_tier||'foundation').toUpperCase())}</b></p><small>${escapeHtml(a.program_version||'mw-41-tiered-v2.9')}</small></div>
        <div class="tile"><h3>Strength Tier</h3><p><b>${escapeHtml(String(a.strength_tier||'foundation').toUpperCase())}</b></p><small>Shared with athlete + Coach MW</small></div>
        <div class="tile"><h3>Starting Week</h3><p>${Number(a.starting_week||1)}</p><small>Program start: ${escapeHtml(fmtDate(a.program_start_date))}</small></div>
        <div class="tile"><h3>Last Workout</h3><p>${escapeHtml(fmtDate(a.last_completed_workout_at))}</p><small>Live MW athlete record</small></div>
      </div>
      <div class="tile" style="margin-top:14px"><h3>Performance Intelligence</h3>${!repTrackingEnabled?'<div class="lockNote"><b>MW SPRINT PERFORMANCE EXCLUSIVE</b><br>Rep-by-rep sprint tracking is available only inside the MW Sprint Performance System.</div>':perf?.sprint?.latest?`<div class="panel-grid" style="margin-top:10px"><div class="tile"><h3>Pace Execution</h3><p><b>${perf.sprint.latest.execution_score_pct??'—'}%</b></p><small>${perf.sprint.latest.source==='quick_checkin'?'Quick athlete check-in':'Detailed timed session'}</small></div><div class="tile"><h3>Consistency</h3><p><b>${perf.sprint.latest.consistency_score??'—'}</b></p><small>Rep execution score</small></div><div class="tile"><h3>Late Drop-Off</h3><p><b>${perf.sprint.latest.first_to_last_dropoff_pct??'—'}%</b></p><small>First rep → last rep</small></div><div class="tile"><h3>Session RPE</h3><p><b>${perf.sprint.latest.session_rpe??'—'}/10</b></p><small>Athlete reported effort</small></div></div><p style="margin-top:10px"><b>${escapeHtml(perf.sprint.latest.reason||'Performance recorded')}</b><br><small>Trend: ${escapeHtml(String(perf.sprint.trend||'insufficient data').replaceAll('_',' '))}. These are coaching signals, not medical conclusions.</small></p><div class="list" style="margin-top:10px">${(perf.sprint.sessions||[]).slice(0,5).map(x=>`<div class="row"><span><b>Week ${x.program_week} · Day ${x.program_day}</b><br><small>${x.rep_count} timed reps · ${x.session_rpe?`RPE ${x.session_rpe}/10 · `:''}${escapeHtml(x.reason||'Recorded')}</small></span><b>${x.execution_score_pct==null?'—':x.execution_score_pct+'%'}</b></div>`).join('')}</div>`:'<p>No pace check-in yet. Once the athlete taps DONE, their pace check-in will appear here.</p>'}${perf?.strength?.latest_checkin?`<div style="margin-top:14px;border-top:1px solid #263641;padding-top:12px"><h3>Strength Check-In</h3><p><b>${perf.strength.latest_checkin.status==='as_prescribed'?'✓ Completed as written':'↔ Modified'}</b></p><small>Week ${perf.strength.latest_checkin.program_week} · ${escapeHtml(perf.strength.latest_checkin.day_label||'Strength day')}</small></div>`:''}${perf?.strength?.latest?`<details style="margin-top:12px"><summary style="cursor:pointer;color:#adbdc8">Detailed strength log</summary><p>${perf.strength.latest.set_count} logged sets · ${perf.strength.latest.actual_volume??0} volume (${escapeHtml(perf.strength.latest.sets?.[0]?.weight_unit||'lb')})</p><small>${escapeHtml((perf.strength.latest.exercises||[]).join(' · '))}</small></details>`:''}</div>
      <div class="tile" style="margin-top:14px"><h3>Coach-Assigned Training Check-Ins</h3>${assignedCheckins.length?`<div class="list">${assignedCheckins.slice(0,10).map(x=>`<div class="row"><span><b>${escapeHtml(String(x.status||'completed').replaceAll('_',' ').toUpperCase())}</b><br><small>${escapeHtml(fmtDate(x.completed_at))}${x.session_rpe?` · RPE ${x.session_rpe}/10`:''}${x.pace_check_status?` · ${escapeHtml(String(x.pace_check_status).replaceAll('_',' '))}`:''}${x.pace_reps_total!=null?` · ${Number(x.pace_reps_hit||0)}/${Number(x.pace_reps_total)} reps`:''}</small>${x.athlete_note?`<br><small>${escapeHtml(x.athlete_note)}</small>`:''}</span></div>`).join('')}</div>`:'<p>No coach-assigned training check-ins yet.</p>'}</div>
      <div class="tile" style="margin-top:14px"><h3>Personal Records</h3>${prs.length?`<div class="list">${prs.map(pr=>`<div class="row"><span><b>${escapeHtml(pr.event)}</b><br><small>${pr.verified?'Verified':'Athlete entered'} · ${pr.timing_method==='fat'?'Fully automatic':pr.timing_method==='hand'?'Hand timed':'Timing unknown'}${pr.date_recorded?' · '+escapeHtml(fmtDate(pr.date_recorded)):''}</small></span><b>${escapeHtml(String(pr.time_seconds))}s</b></div>`).join('')}</div>`:'<p>No PRs recorded yet.</p>'}</div>
      <div class="tile" style="margin-top:14px"><h3>Assessment Weight-Room Maximums</h3>${a.strength_maxes?`<div class="list"><div class="row"><span>Power Clean</span><b>${a.strength_maxes.power_clean_max??'Not established'} ${a.strength_maxes.power_clean_max!=null?escapeHtml(a.strength_maxes.weight_unit||'lb'):''}</b></div><div class="row"><span>Front Squat</span><b>${a.strength_maxes.front_squat_max??'Not established'} ${a.strength_maxes.front_squat_max!=null?escapeHtml(a.strength_maxes.weight_unit||'lb'):''}</b></div><div class="row"><span>Back Squat</span><b>${a.strength_maxes.back_squat_max??'Not established'} ${a.strength_maxes.back_squat_max!=null?escapeHtml(a.strength_maxes.weight_unit||'lb'):''}</b></div><div class="row"><span>${a.strength_maxes.deadlift_type==='trap_bar'?'Trap-Bar Deadlift':'Deadlift'}</span><b>${a.strength_maxes.deadlift_max??'Not established'} ${a.strength_maxes.deadlift_max!=null?escapeHtml(a.strength_maxes.weight_unit||'lb'):''}</b></div></div>`:'<p>No lifting maximums established. Use Foundation technique loading.</p>'}</div>
      <div class="form" style="margin-top:14px"><h3>Coach-Approved Assignment</h3><label>Track Tier<select id="athTrackTier"><option value="foundation">Foundation</option><option value="development">Development</option><option value="performance">Performance</option></select></label><label>Strength Tier<select id="athStrengthTier"><option value="foundation">Foundation</option><option value="development">Development</option><option value="performance">Performance</option></select></label><label>Official Week<input id="athProgramWeek" type="number" min="1" max="41" value="${Number(a.current_week||1)}"></label><label>Reason<textarea id="athAssignmentReason" rows="3" maxlength="1000" placeholder="Why is this assignment appropriate?"></textarea></label><button class="action" id="saveAthAssignment">Approve & Sync Assignment</button><div id="athAssignmentState"></div></div>
      <div class="tile" style="margin-top:14px"><h3>Private Coach Notes</h3><div id="athleteNotes">${notes.length?notes.map(n=>`<div class="row"><span>${escapeHtml(n.note)}<br><small>${escapeHtml(fmtDate(n.created_at))}</small></span></div>`).join(''):'<p>No coach notes yet.</p>'}</div></div>
      <div class="form" style="margin-top:14px"><label>Add Private Coach Note<textarea rows="4" id="athNote" maxlength="5000" placeholder="Add a private coaching note…"></textarea></label><button class="action" id="saveAthNote">Save Note</button><div id="athNoteState"></div></div>
    </div>`;
    modal.querySelector('#athTrackTier').value=a.track_tier||'foundation';
    modal.querySelector('#athStrengthTier').value=a.strength_tier||'foundation';
    modal.querySelector('#saveAthAssignment').onclick=async()=>{
      const btn=modal.querySelector('#saveAthAssignment'),msg=modal.querySelector('#athAssignmentState');btn.disabled=true;btn.textContent='Syncing…';msg.textContent='';
      try{const payload={action:'update_assignment',athleteId,trackTier:modal.querySelector('#athTrackTier').value,strengthTier:modal.querySelector('#athStrengthTier').value,week:Number(modal.querySelector('#athProgramWeek').value),reason:modal.querySelector('#athAssignmentReason').value.trim()};const rr=await fetch('/api/coach/athlete',{method:'POST',headers:{Authorization:`Bearer ${mwSessionToken()}`,'Content-Type':'application/json'},body:JSON.stringify(payload)});const dd=await rr.json().catch(()=>({}));if(!rr.ok)throw new Error(dd.error||'Assignment could not be synced.');msg.textContent='✓ Saved. Athlete app, coach dashboard, and Coach MW now use this assignment.';toast('Athlete assignment synced')}catch(e){msg.textContent=e.message}finally{btn.disabled=false;btn.textContent='Approve & Sync Assignment'}
    };
    modal.querySelector('#saveAthNote').onclick=async()=>{
      const text=modal.querySelector('#athNote').value.trim(),btn=modal.querySelector('#saveAthNote'),msg=modal.querySelector('#athNoteState');
      if(!text)return toast('Enter a note first');btn.disabled=true;btn.textContent='Saving…';msg.textContent='';
      try{const rr=await fetch('/api/coach/athlete',{method:'POST',headers:{Authorization:`Bearer ${mwSessionToken()}`,'Content-Type':'application/json'},body:JSON.stringify({athleteId,note:text})});const dd=await rr.json().catch(()=>({}));if(!rr.ok)throw new Error(dd.error||'Note could not be saved.');modal.querySelector('#athNote').value='';msg.textContent='Saved to MW Dynasty.';const notesEl=modal.querySelector('#athleteNotes');const empty=notesEl.querySelector('p');if(empty)notesEl.innerHTML='';notesEl.insertAdjacentHTML('afterbegin',`<div class="row"><span>${escapeHtml(text)}<br><small>Just now</small></span></div>`);toast('Coach note saved')}catch(e){msg.textContent=e.message}finally{btn.disabled=false;btn.textContent='Save Note'}
    };
  }catch(e){state.innerHTML=`<h3>Could not open athlete</h3><p>${escapeHtml(e.message)}</p>`}
}
async function inviteAthleteModal(){
  const sponsorPrice=PLANS[experience].sponsor;
  const modal=mwModal('Invite Athlete',`<div class="tile"><h3>Connect an athlete to your dashboard</h3><p>The athlete can be new to MW Dynasty or already have an account. Choose who is paying before you send the invitation.</p></div><div class="form" style="margin-top:14px"><label>Athlete Email<input id="inviteEmail" type="email" inputmode="email" placeholder="athlete@example.com"></label><label>Invite Type<select id="inviteType"><option value="coach_invite">Coach invitation</option><option value="team_invite">Team invitation</option></select></label><label>Who is paying?<select id="inviteBillingType"><option value="coach_sponsored">I'm sponsoring this athlete (+$${sponsorPrice}/month)</option><option value="self_pay">Athlete pays for their own membership</option></select></label><div class="tile" id="inviteBillingHelp"><b>Coach Sponsored</b><br><small>The athlete creates or signs into their profile and skips membership checkout. Their MW access is billed to your coach account.</small></div><button class="action" id="createInvite">Create Secure Invitation</button><div id="inviteState" class="tile" style="display:none"></div></div>`);
  const billingSelect=modal.querySelector('#inviteBillingType'),billingHelp=modal.querySelector('#inviteBillingHelp');
  billingSelect.onchange=()=>{billingHelp.innerHTML=billingSelect.value==='coach_sponsored'?`<b>Coach Sponsored</b><br><small>The athlete creates or signs into their profile and skips membership checkout. Your current sponsored-athlete rate is +$${sponsorPrice}/month.</small>`:`<b>Athlete Self-Pay</b><br><small>The invitation connects the athlete to you, but the athlete is responsible for their own MW Athlete membership.</small>`};
  modal.querySelector('#createInvite').onclick=async()=>{
    const email=modal.querySelector('#inviteEmail').value.trim().toLowerCase(),state=modal.querySelector('#inviteState'),btn=modal.querySelector('#createInvite'),billingType=billingSelect.value;
    if(!email||!email.includes('@'))return toast('Enter a valid athlete email');btn.disabled=true;btn.textContent='Creating…';
    try{const token=mwSessionToken();if(!token)throw new Error('Coach session expired. Sign in again.');const r=await fetch('/api/coach/invite',{method:'POST',headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json'},body:JSON.stringify({email,inviteType:modal.querySelector('#inviteType').value,billingType})});const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.error||'Invitation could not be created');const inv=d.invitation||{},isSponsored=(inv.billing_type||billingType)==='coach_sponsored';state.style.display='block';state.innerHTML=`<h3>${d.reused?'Pending Invitation Ready':'Invitation Created'}</h3><p><b>${escapeHtml(email)}</b></p><p>${isSponsored?'Coach Sponsored':'Athlete Self-Pay'} · Pending · expires ${escapeHtml(fmtDate(inv.expires_at))}</p><p><b>${d.emailSent?'✓ Invitation email sent':'⚠ Invitation email not sent'}</b>${d.emailError?`<br><small>${escapeHtml(d.emailError)}</small>`:''}</p>${d.inviteUrl?`<label>Invite Link<input id="inviteLink" readonly value="${escapeHtml(d.inviteUrl)}"></label><button class="back" id="copyInviteLink" type="button">Copy Invite Link</button>`:''}<label>Backup Invite Code<input id="inviteCode" readonly value="${escapeHtml(inv.invite_token||'')}"></label><button class="back" id="copyInvite" type="button">Copy Backup Code</button><p><small>${isSponsored?'When accepted, the athlete profile is covered by your sponsorship.':'When accepted, the athlete is connected to you and keeps responsibility for their own membership.'}</small></p>`;const copy=async(id,label)=>{const input=modal.querySelector(id);if(!input)return;try{await navigator.clipboard.writeText(input.value);toast(label)}catch{input.select();document.execCommand('copy');toast(label)}};modal.querySelector('#copyInviteLink')?.addEventListener('click',()=>copy('#inviteLink','Invite link copied'));modal.querySelector('#copyInvite').onclick=()=>copy('#inviteCode','Invite code copied');}catch(e){state.style.display='block';state.innerHTML=`<h3>Invitation Error</h3><p>${escapeHtml(e.message)}</p>`}finally{btn.disabled=false;btn.textContent='Create Secure Invitation'}
  };
}
async function athletesPage(){
  pageBase('Athletes',accountAccess.role==='coach'?'Only athletes actively assigned to your coach account appear here.':'Founder/Admin athlete roster.',`<div id="athleteList" class="list"><div class="tile">Loading live MW roster…</div></div><button class="action" id="inviteAthlete" style="margin-top:14px">+ Invite Athlete</button><div id="pendingInviteWrap" style="margin-top:18px"></div>`);
  document.getElementById('inviteAthlete').onclick=inviteAthleteModal;
  const list=document.getElementById('athleteList');
  try{
    const d=await fetchCoachRoster(),athletes=Array.isArray(d.athletes)?d.athletes:[],pending=Array.isArray(d.pendingInvitations)?d.pendingInvitations:[];
    const pendingWrap=document.getElementById('pendingInviteWrap');
    if(pendingWrap&&pending.length)pendingWrap.innerHTML=`<div class="tile"><h3>Pending Athlete Invitations</h3><div class="list">${pending.map(i=>`<div class="row"><span><b>${escapeHtml(i.athlete_email)}</b><br><small>${escapeHtml(i.billing_type==='coach_sponsored'?'Coach Sponsored':'Athlete Self-Pay')} · Pending · expires ${escapeHtml(fmtDate(i.expires_at))}</small></span></div>`).join('')}</div></div>`;
    if(!athletes.length){list.innerHTML=`<div class="tile"><h3>No assigned athletes yet</h3><p>${d.scope==='assigned'?'This coach account currently has no active athlete assignments. Invite an athlete, and they will appear here once the connection is accepted.':'No athlete accounts are available yet.'}</p></div>`;return}
    list.innerHTML=athletes.map(a=>`<div class="row"><span><b>${escapeHtml(a.name)}</b><br><small>${escapeHtml(a.event||'Events not set')} · Week ${Number(a.current_week||1)} · ${escapeHtml(String(a.status||'On Track'))}</small></span><button class="action athlete-open" data-athlete-id="${escapeHtml(a.id)}">Open</button></div>`).join('');
    list.querySelectorAll('.athlete-open').forEach(b=>b.onclick=()=>athleteDetail(b.dataset.athleteId));
  }catch(e){list.innerHTML=`<div class="tile"><h3>Roster unavailable</h3><p>${escapeHtml(e.message)}</p><button class="back" id="retryRoster">Try Again</button></div>`;document.getElementById('retryRoster').onclick=athletesPage}
}
function teamWorkspace(name){mwModal(name,`<div class="panel-grid"><div class="tile"><h3>Roster</h3><p>Manage assigned athletes and pending invitations.</p><button class="action" id="teamRoster">View Athletes</button></div><div class="tile"><h3>Team Communication</h3><p>Open the team message composer.</p><button class="action" id="teamMessage">Message Team</button></div><div class="tile"><h3>Attendance</h3><p>Record attendance for this group.</p><button class="action" id="teamAttendance">Take Attendance</button></div></div>`);document.getElementById('teamRoster').onclick=()=>{document.getElementById('mwModal')?.remove();athletesPage()};document.getElementById('teamMessage').onclick=()=>{document.getElementById('mwModal')?.remove();messagesPage()};document.getElementById('teamAttendance').onclick=()=>{document.getElementById('mwModal')?.remove();attendancePage()}}
function teamsPage(){const teams=['Varsity Sprint Group','Development Group','400m Group','Relays'];pageBase('Teams','Manage squads, groups and coach assignments.',`<div class="panel-grid">${teams.map(n=>`<div class="tile"><h3>${n}</h3><p>Roster, attendance, messages and assignments.</p><button class="action team-open" data-team="${n}" style="margin-top:12px">Open Team</button></div>`).join('')}</div>`);document.querySelectorAll('.team-open').forEach(b=>b.onclick=()=>teamWorkspace(b.dataset.team))}
function programsPage(){const saved=mwLoad('program',`Monday — Acceleration\nTuesday — Tempo + Strength\nWednesday — Recovery\nThursday — Max Velocity\nFriday — Speed Endurance`);pageBase(experience==='performance'?'MW Track Program':'My Program',experience==='performance'?'41-week MW training system.':'Bring your own program and manage workouts.',`<div class="form"><label>Program / Weekly Plan<textarea id="programText" rows="11">${escapeHtml(saved)}</textarea></label><div style="display:flex;gap:10px;flex-wrap:wrap"><button class="action" id="saveProgram">Save Program</button><button class="back" id="previewProgram">Preview Week</button></div></div>`);document.getElementById('saveProgram').onclick=()=>{mwStore('program',document.getElementById('programText').value);toast('Program saved on this coach device')};document.getElementById('previewProgram').onclick=()=>mwModal('Program Preview',`<div class="tile"><pre style="white-space:pre-wrap;margin:0">${escapeHtml(document.getElementById('programText').value)}</pre></div>`)}
function calendarPage(){const ev=[['APR 12','Spring Invitational','Huntsville, AL'],['APR 19','County Championship','Birmingham, AL'],['MAY 3','State Qualifier','Montgomery, AL']];pageBase('Calendar','Practice, meet and team schedule.',`<div class="list">${ev.map((e,i)=>`<div class="row"><span><b>${e[0]} · ${e[1]}</b><br><small>${e[2]}</small></span><button class="action cal-open" data-i="${i}">Open</button></div>`).join('')}</div><button class="action" id="addCalendar" style="margin-top:14px">+ Add Event</button>`);document.querySelectorAll('.cal-open').forEach(b=>b.onclick=()=>{const e=ev[+b.dataset.i];mwModal(e[1],`<div class="form"><label>Date<input value="${e[0]}"></label><label>Location<input value="${e[2]}"></label><label>Notes<textarea rows="4" placeholder="Meet or practice notes..."></textarea></label><button class="action" data-close-modal>Done</button></div>`) });document.getElementById('addCalendar').onclick=()=>mwModal('Add Calendar Event',`<div class="form"><label>Event Name<input id="eventName"></label><label>Date<input id="eventDate" type="date"></label><label>Location<input id="eventLocation"></label><button class="action" id="saveEvent">Save Event</button></div>`);setTimeout(()=>{const b=document.getElementById('saveEvent');if(b)b.onclick=()=>{const x=mwLoad('calendarEvents',[]);x.push({name:eventName.value,date:eventDate.value,location:eventLocation.value});mwStore('calendarEvents',x);toast('Calendar event saved');document.getElementById('mwModal')?.remove()}},0)}
function meetModal(name,location){const states=mwLoad('meetStatus',{});mwModal(name,`<div class="form"><label>Location<input value="${escapeHtml(location)}" readonly></label><label>Registration Status<select id="meetStatus"><option ${states[name]==='Registered'?'selected':''}>Registered</option><option ${states[name]==='Not Registered'?'selected':''}>Not Registered</option></select></label><label>Coach Notes<textarea id="meetNotes" rows="4" placeholder="Entries, travel, readiness notes..."></textarea></label><button class="action" id="saveMeet">Save Meet</button></div>`);document.getElementById('saveMeet').onclick=()=>{states[name]=document.getElementById('meetStatus').value;mwStore('meetStatus',states);toast('Meet updated');document.getElementById('mwModal')?.remove();meetsPage()}}
function meetsPage(){const meets=[['Spring Invitational','Huntsville, AL'],['County Championship','Birmingham, AL'],['State Qualifier','Montgomery, AL']];const states=mwLoad('meetStatus',{});pageBase('Meets','Manage registration and meet readiness.',`<div class="list">${meets.map(([n,l])=>`<div class="row"><span><b>${n}</b><br>${l}</span><button class="action meet-open" data-name="${n}" data-loc="${l}">${states[n]||'Open Meet'}</button></div>`).join('')}</div>`);document.querySelectorAll('.meet-open').forEach(b=>b.onclick=()=>meetModal(b.dataset.name,b.dataset.loc))}
async function attendancePage(){
  pageBase('Attendance','Attendance is recorded only for athletes this coach is authorized to manage.',`<div class="form"><label>Session Date<input id="attDate" type="date" value="${new Date().toISOString().slice(0,10)}"></label><label>Session Type<input id="attType" value="training"></label></div><div class="list" id="attList"><div class="tile">Loading assigned athletes…</div></div><button class="action" id="saveAttendance" style="margin-top:14px" disabled>Save Attendance</button><div id="attState" class="tile" style="display:none;margin-top:12px"></div>`);
  const list=document.getElementById('attList'),save=document.getElementById('saveAttendance'),st=document.getElementById('attState');
  try{
    const d=await fetchCoachRoster(),athletes=Array.isArray(d.athletes)?d.athletes:[];
    if(!athletes.length){list.innerHTML='<div class="tile"><h3>No athletes available</h3><p>Attendance can be taken after an athlete is actively assigned to this coach.</p></div>';return}
    list.innerHTML=athletes.map(a=>`<div class="row"><span><b>${escapeHtml(a.name)}</b><br><small>${escapeHtml(a.event||'Events not set')}</small></span><select data-att-athlete="${escapeHtml(a.id)}" aria-label="Attendance for ${escapeHtml(a.name)}"><option value="present">Present</option><option value="absent">Absent</option><option value="excused">Excused</option><option value="injured">Injured</option><option value="late">Late</option></select></div>`).join('');
    save.disabled=false;
    save.onclick=async()=>{
      const rows=[...document.querySelectorAll('[data-att-athlete]')];if(!rows.length)return;
      save.disabled=true;save.textContent='Saving…';st.style.display='block';st.textContent='Saving live attendance…';
      try{
        const token=mwSessionToken(),sessionDate=document.getElementById('attDate').value,sessionType=document.getElementById('attType').value.trim()||'training';
        const results=await Promise.all(rows.map(async el=>{const r=await fetch('/api/coach/attendance',{method:'POST',headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json'},body:JSON.stringify({athleteId:el.dataset.attAthlete,status:el.value,sessionDate,sessionType})});const x=await r.json().catch(()=>({}));if(!r.ok)throw new Error(x.error||'Attendance save failed');return x}));
        st.innerHTML=`<b>Attendance saved.</b><p>${results.length} athlete record${results.length===1?'':'s'} synced to MW Dynasty.</p>`;toast('Live attendance saved');
      }catch(e){st.innerHTML=`<b>Attendance error</b><p>${escapeHtml(e.message)}</p>`}finally{save.disabled=false;save.textContent='Save Attendance'}
    };
  }catch(e){list.innerHTML=`<div class="tile"><h3>Attendance roster unavailable</h3><p>${escapeHtml(e.message)}</p></div>`}
}
function messagesPage(){const history=mwLoad('messages',[]);pageBase('Messages','Communicate with athletes and teams.',`<div class="form"><label>Audience<select id="msgAudience"><option>Entire Team</option><option>Varsity Sprint Group</option><option>Development Group</option><option>400m Group</option><option>Relays</option></select></label><label>Message<textarea id="msgText" rows="6" placeholder="Message the team..."></textarea></label><button class="action" id="sendMsg">Send Message</button></div><div class="list" id="msgHistory" style="margin-top:16px">${history.slice(-5).reverse().map(m=>`<div class="row"><span><b>${escapeHtml(m.audience)}</b><br>${escapeHtml(m.text)}</span><small>${escapeHtml(m.time)}</small></div>`).join('')||'<div class="tile">No coach messages sent from this device yet.</div>'}</div>`);document.getElementById('sendMsg').onclick=()=>{const text=msgText.value.trim();if(!text)return toast('Write a message first');history.push({audience:msgAudience.value,text,time:new Date().toLocaleString()});mwStore('messages',history);msgText.value='';toast('Message recorded');messagesPage()}}
function supportPage(){pageBase('Help & Support','Send a real support request to MW Dynasty.',`<div class="form"><label>Category<select id="supportCategory"><option value="app_issue">App issue</option><option value="account">Account</option><option value="training_data">Training data</option><option value="privacy">Privacy</option><option value="other">Other</option></select></label><label>Subject<input id="supportSubject" maxlength="120" placeholder="Short summary"></label><label>Request<textarea id="supportText" maxlength="4000" rows="6" placeholder="How can we help?"></textarea></label><button class="action" id="submitSupport">Submit Request</button><div id="supportState" class="tile" style="display:none"></div></div>`);document.getElementById('submitSupport').onclick=async()=>{const s=supportSubject.value.trim(),text=supportText.value.trim(),state=document.getElementById('supportState'),btn=document.getElementById('submitSupport');if(!s||text.length<5)return toast('Add a subject and a little more detail');btn.disabled=true;btn.textContent='Sending…';state.style.display='block';state.textContent='Sending to MW Support…';try{const u=await mwCurrentUser();if(!u?.id)throw new Error('Coach session expired. Sign in again.');await sbRest('support_requests',{method:'POST',prefer:'return=minimal',body:{user_id:u.id,athlete_id:null,category:supportCategory.value,message:`${s}\n\n${text}`,app_version:MW_APP_VERSION,device_info:navigator.userAgent}});state.innerHTML='<b>✓ Request sent.</b><p>MW Support received your coach support request.</p>';supportSubject.value='';supportText.value=''}catch(e){state.innerHTML=`<b>Support request failed.</b><p>${escapeHtml(e.message)}</p>`}finally{btn.disabled=false;btn.textContent='Submit Request'}}}
function taskBoardPage(){let tasks=mwLoad('aiTasks',[{name:'Maya T. — Missed Training',detail:'Review workload before next high-intensity day.',status:'Review'},{name:'Tyler B. — Performance Trend',detail:'Flying 30 trend improved across three sessions.',status:'Approve'},{name:'Aaliyah R. — Meet Preparation',detail:'Competition warm-up and race-model review are due.',status:'Open'}]);pageBase('AI Task Board','Daily coaching tasks and priorities.',`<div class="list">${tasks.map((t,i)=>`<div class="row"><span><b>${escapeHtml(t.name)}</b><br>${escapeHtml(t.detail)}<br><small>Status: ${escapeHtml(t.status)}</small></span><button class="action task-open" data-i="${i}">Open Task</button></div>`).join('')}</div>`);document.querySelectorAll('.task-open').forEach(b=>b.onclick=()=>{const i=+b.dataset.i,t=tasks[i];mwModal('AI Task',`<div class="tile"><h3>${escapeHtml(t.name)}</h3><p>${escapeHtml(t.detail)}</p></div><div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:12px"><button class="action" id="approveTask">Approve</button><button class="back" id="holdTask">Hold</button></div>`);approveTask.onclick=()=>{tasks[i].status='Approved';mwStore('aiTasks',tasks);document.getElementById('mwModal')?.remove();taskBoardPage()};holdTask.onclick=()=>{tasks[i].status='Held';mwStore('aiTasks',tasks);document.getElementById('mwModal')?.remove();taskBoardPage()}})}
async function seasonPage(){const rec=mwLoad('seasonRecommendation',null);pageBase('AI Season Planner','Build and optimize the season while keeping the coach in control.',`<div class="panel-grid"><div class="tile"><h3>Training-Year Position</h3><p id="seasonPlannerCalendar">Loading MW season calendar…</p></div><div class="tile"><h3>Next Meet</h3><p>Use Calendar / Meets to connect the next competition.</p></div></div><div class="form" style="margin-top:14px"><label>Season Goal<textarea id="seasonGoal" rows="4" placeholder="What should the team be ready for?"></textarea></label><button class="action" id="genSeason">Generate Recommendation</button><div id="seasonOut" class="tile" style="${rec?'':'display:none;'}">${rec?escapeHtml(rec):''}</div></div>`);try{const c=await coachSeasonCalendarRequest();const el=document.getElementById('seasonPlannerCalendar');if(el)el.textContent=coachCalendarSummary(c)}catch(e){const el=document.getElementById('seasonPlannerCalendar');if(el)el.textContent=e.message}document.getElementById('genSeason').onclick=()=>{const goal=seasonGoal.value.trim()||'Protect speed quality while preparing for the next meet.';const c=coachSeasonCalendar;const calendar=c?coachCalendarSummary(c):'MW season calendar';const text=`Recommendation: use ${calendar} as the scheduling reference, keep the current phase intent intact, protect high-intensity quality, and review attendance/readiness before any progression. Coach approval is required before changing official program state. Goal: ${goal}`;mwStore('seasonRecommendation',text);seasonOut.style.display='block';seasonOut.textContent=text}}
function adjustmentPage(){let status=mwLoad('seasonAdjustment','Pending coach review');pageBase('AI Season Adjustment','Detect → Analyze → Recommend → Coach Approves → System Executes.',`<div class="tile"><h3>Recommended Adjustment</h3><p>Maya T. missed two sessions. Hold the next high-intensity progression until attendance and readiness are reviewed.</p><p><b>Status:</b> <span id="adjustStatus">${escapeHtml(status)}</span></p><div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:12px"><button class="action" id="approveAdjustment">Approve Adjustment</button><button class="back" id="dismissAdjustment">Dismiss</button></div></div>`);approveAdjustment.onclick=()=>{status='Approved by coach — execution still requires connected program-state action';mwStore('seasonAdjustment',status);adjustStatus.textContent=status};dismissAdjustment.onclick=()=>{status='Dismissed by coach';mwStore('seasonAdjustment',status);adjustStatus.textContent=status}}
function insightsPage(){const items=[['Training Load','Athlete workload is in optimal range.'],['Performance Trend','Sprinters showing a 3.2% improvement.'],['Meet Readiness','8 athletes are on track for PRs.'],['Attendance','Team attendance is currently 91%.']];pageBase('AI Insights','Performance, workload and meet-readiness signals.',`<div class="panel-grid">${items.map((x,i)=>`<div class="tile"><h3>${x[0]}</h3><p>${x[1]}</p><button class="action insight-open" data-i="${i}">Review Insight</button></div>`).join('')}</div>`);document.querySelectorAll('.insight-open').forEach(b=>b.onclick=()=>{const x=items[+b.dataset.i];mwModal(x[0],`<div class="tile"><p>${x[1]}</p><p><b>Coach action:</b> Review supporting athlete data before changing training or progression.</p></div>`)})}
function mwTrackPage(){pageBase('MW Track Program','41-week progressive sprint program.',`<div class="panel-grid">${Array.from({length:41},(_,i)=>i+1).map(w=>`<div class="tile"><h3>Week ${w}</h3><p>${w===12?'Acceleration Development':'MW progressive sprint development'}</p><button class="action week-open" data-week="${w}">Open Week</button></div>`).join('')}</div>`);document.querySelectorAll('.week-open').forEach(b=>b.onclick=()=>mwModal(`MW Track Program · Week ${b.dataset.week}`,`<div class="tile"><h3>Week ${b.dataset.week}</h3><p>Open the coach-authored MW week, review daily sessions, and track completion. This interface is ready for the full 41-week dataset connection.</p></div>`))}
function strengthPage(){pageBase('Strength & Power','MW weight-room program synchronized to the sprint plan.',`<div class="panel-grid">${Array.from({length:41},(_,i)=>i+1).map(w=>`<div class="tile"><h3>Week ${w}</h3><p>Synchronized Strength & Power session.</p><button class="action strength-open" data-week="${w}">Open Session</button></div>`).join('')}</div>`);document.querySelectorAll('.strength-open').forEach(b=>b.onclick=()=>mwModal(`Strength & Power · Week ${b.dataset.week}`,`<div class="tile"><h3>Week ${b.dataset.week}</h3><p>Weight-room session detail workspace. Load calculations, lift prescriptions and athlete completion can be connected to the synchronized strength dataset.</p></div>`))}
function schoolPage(){const lessons=['Sprint Mechanics','Block Starts','Competition Warm-Up','Drill Library'];pageBase('Sprint School','Technique & education.',`<div class="panel-grid">${lessons.map(x=>`<div class="tile"><h3>${x}</h3><p>MW Sprint School lesson.</p><button class="action lesson-open" data-lesson="${x}">Open Lesson</button></div>`).join('')}</div>`);document.querySelectorAll('.lesson-open').forEach(b=>b.onclick=()=>mwModal(b.dataset.lesson,`<div class="tile"><h3>${escapeHtml(b.dataset.lesson)}</h3><p>Coach-facing lesson workspace with teaching points, athlete assignment, and completion controls.</p></div><button class="action" id="assignLesson">Assign to Team</button>`))}
function racePage(){const lessons=['100m Race Strategy','200m Race Strategy','400m Race Strategy','Block Start Strategy'];pageBase('Race Strategy','100m · 200m · 400m blueprints.',`<div class="panel-grid">${lessons.map(x=>`<div class="tile"><h3>${x}</h3><p>MW race execution blueprint.</p><button class="action race-open" data-race="${x}">Open Blueprint</button></div>`).join('')}</div>`);document.querySelectorAll('.race-open').forEach(b=>b.onclick=()=>mwModal(b.dataset.race,`<div class="tile"><h3>${escapeHtml(b.dataset.race)}</h3><p>Coach-facing race blueprint workspace for teaching, review and athlete assignment.</p></div>`))}
function bindPageActions(){document.querySelectorAll('[data-toast]').forEach(b=>b.onclick=()=>{const msg=b.dataset.toast||'Action opened';mwModal('Coach Workspace',`<div class="tile"><h3>${escapeHtml(msg)}</h3><p>This action now opens a real workspace instead of a temporary toast-only placeholder.</p></div>`)})}


async function coachAdminRequest(method='GET',body=null){
  const token=mwSessionToken();if(!token)throw new Error('Founder session required.');
  const r=await fetch(`${SUPABASE_URL}/functions/v1/mw-coach-applications-admin`,{method,headers:{apikey:SUPABASE_KEY,Authorization:`Bearer ${token}`,...(body?{'Content-Type':'application/json'}:{})},body:body?JSON.stringify(body):undefined});
  const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.error||'Coach application request failed.');return d;
}
async function coachApplicationsPage(){
  if(!accountAccess.isFounder){toast('Founder access required');return dashboard()}
  pageBase('Coach Applications','Review every coach before MW Dynasty access is granted.',`<div class="founder-app-head"><div><b>Vetted Coach Access</b><p>Approve the coach, assign exactly one tier, then MW Dynasty sends the secure invitation.</p></div><button class="back" id="refreshCoachApps">Refresh</button></div><div id="coachAppsState" class="tile">Loading applications…</div><div id="coachAppsList" class="founder-app-list"></div>`);
  const load=async()=>{const state=document.getElementById('coachAppsState'),list=document.getElementById('coachAppsList');state.style.display='block';state.textContent='Loading applications…';list.innerHTML='';try{const d=await coachAdminRequest();const apps=d.applications||[];state.textContent=apps.length?`${apps.filter(a=>a.status==='pending').length} pending · ${apps.length} total application${apps.length===1?'':'s'}`:'No coach applications yet.';list.innerHTML=apps.map(a=>`<article class="founder-app-card"><div class="founder-app-top"><div><span class="founder-status ${escapeHtml(a.status)}">${escapeHtml(a.status)}</span><h3>${escapeHtml(a.first_name)} ${escapeHtml(a.last_name)}</h3><p>${escapeHtml(a.email)}${a.organization?' · '+escapeHtml(a.organization):''}</p></div><small>${new Date(a.created_at).toLocaleDateString()}</small></div><div class="founder-app-meta"><span>${escapeHtml(a.coaching_level||'Level not provided')}</span><span>${a.years_coaching??'—'} years</span><span>${escapeHtml([a.city,a.state].filter(Boolean).join(', ')||'Location not provided')}</span></div><p class="founder-reason">${escapeHtml(a.reason)}</p>${a.status==='pending'?`<div class="founder-review"><label>Coach Tier<select data-tier="${a.id}"><option value="core">MW Coach Core</option><option value="intelligence">Coach Intelligence</option><option value="mw_sprint_performance">MW Sprint Performance</option></select></label><label>Founder Notes<textarea rows="2" data-notes="${a.id}" placeholder="Optional internal review notes"></textarea></label><div class="founder-actions"><button class="action" data-approve="${a.id}">Approve + Send Invite</button><button class="back founder-reject" data-reject="${a.id}">Reject</button></div></div>`:`<div class="founder-reviewed"><b>${a.access_tier?escapeHtml(tierLabel(a.access_tier)):escapeHtml(a.status)}</b>${a.invited_at?`<span>Invitation sent ${new Date(a.invited_at).toLocaleDateString()}</span>`:''}</div>`}</article>`).join('');bindCoachApplicationActions(load)}catch(e){state.textContent=e.message}};document.getElementById('refreshCoachApps').onclick=load;load();
}
function tierLabel(t){return ({core:'MW Coach Core',intelligence:'Coach Intelligence',mw_sprint_performance:'MW Sprint Performance'})[t]||t}
function bindCoachApplicationActions(reload){
  document.querySelectorAll('[data-approve]').forEach(b=>b.onclick=async()=>{const id=b.dataset.approve,tier=document.querySelector(`[data-tier="${id}"]`).value,notes=document.querySelector(`[data-notes="${id}"]`).value;b.disabled=true;b.textContent='Approving…';try{const d=await coachAdminRequest('POST',{id,action:'approve',access_tier:tier,review_notes:notes});toast(d.message||'Coach approved and invitation sent');await reload()}catch(e){toast(e.message);b.disabled=false;b.textContent='Approve + Send Invite'}});
  document.querySelectorAll('[data-reject]').forEach(b=>b.onclick=async()=>{const id=b.dataset.reject;const reason=prompt('Reason for rejecting this coach application?')||'';if(!reason.trim())return; b.disabled=true;try{await coachAdminRequest('POST',{id,action:'reject',rejection_reason:reason,review_notes:document.querySelector(`[data-notes="${id}"]`)?.value||''});toast('Coach application rejected');await reload()}catch(e){toast(e.message);b.disabled=false}})
}


// === V12.0 CONNECTED COACH OPERATING SYSTEM ===
async function sbRest(path,{method='GET',body=null,prefer='return=representation'}={}){
  const token=mwSessionToken();if(!token)throw new Error('Coach session expired. Sign in again.');
  const r=await fetch(`${SUPABASE_URL}/rest/v1/${path}`,{method,headers:{apikey:SUPABASE_KEY,Authorization:`Bearer ${token}`,...(body?{'Content-Type':'application/json'}:{}),...(prefer?{Prefer:prefer}:{})},body:body?JSON.stringify(body):undefined});
  const d=await r.json().catch(()=>null);if(!r.ok)throw new Error(d?.message||d?.hint||`MW data request failed (${r.status})`);return d;
}
async function logCoachAction(action_type,entity_type=null,entity_id=null,detail={}){try{const u=await mwCurrentUser();if(u?.id)await sbRest('coach_activity_log',{method:'POST',body:{coach_user_id:u.id,action_type,entity_type,entity_id,detail}})}catch{}}
async function liveGroups(){return await sbRest('coach_groups?select=id,name,event_group,description,archived,created_at&archived=eq.false&order=created_at.asc')||[]}
async function liveGroupMembers(groupId){return await sbRest(`coach_group_members?select=id,athlete_id,created_at&group_id=eq.${encodeURIComponent(groupId)}&order=created_at.asc`)||[]}
async function teamsPage(){
  pageBase('Teams / Groups','Create real coaching groups and organize only athletes you are authorized to manage.',`<div style="display:flex;justify-content:flex-end;margin-bottom:14px"><button class="action" id="newGroup">+ Create Group</button></div><div id="groupsLive" class="panel-grid"><div class="tile">Loading live groups…</div></div>`);
  document.getElementById('newGroup').onclick=createGroupModal;const wrap=document.getElementById('groupsLive');
  try{const groups=await liveGroups();if(!groups.length){wrap.innerHTML='<div class="tile"><h3>No groups yet</h3><p>Create your first squad, event group, or relay unit.</p></div>';return}const counts=await Promise.all(groups.map(g=>liveGroupMembers(g.id).then(x=>x.length).catch(()=>0)));wrap.innerHTML=groups.map((g,i)=>`<div class="tile"><h3>${escapeHtml(g.name)}</h3><p>${escapeHtml(g.event_group||'General')} · ${counts[i]} athlete${counts[i]===1?'':'s'}</p><p>${escapeHtml(g.description||'Coach-managed MW group')}</p><button class="action group-open" data-id="${g.id}" style="margin-top:12px">Open Group</button></div>`).join('');wrap.querySelectorAll('.group-open').forEach(b=>b.onclick=()=>groupWorkspaceLive(b.dataset.id));}catch(e){wrap.innerHTML=`<div class="tile"><h3>Groups unavailable</h3><p>${escapeHtml(e.message)}</p></div>`}
}
function createGroupModal(){mwModal('Create Team / Group',`<div class="form"><label>Group Name<input id="groupName" placeholder="100m / 200m Group"></label><label>Event Group<input id="groupEvent" placeholder="Sprints, 400m, Relays..."></label><label>Description<textarea id="groupDesc" rows="3"></textarea></label><button class="action" id="saveGroup">Create Group</button></div>`);document.getElementById('saveGroup').onclick=async()=>{const name=groupName.value.trim();if(!name)return toast('Group name required');const u=await mwCurrentUser();try{const d=await sbRest('coach_groups',{method:'POST',body:{coach_user_id:u.id,name,event_group:groupEvent.value.trim()||null,description:groupDesc.value.trim()||null,archived:false}});await logCoachAction('group_created','coach_group',d?.[0]?.id,{name});document.getElementById('mwModal')?.remove();teamsPage();toast('Group created')}catch(e){toast(e.message)}}}
async function groupWorkspaceLive(id){
  try{const [groups,members,roster]=await Promise.all([sbRest(`coach_groups?select=*&id=eq.${encodeURIComponent(id)}&limit=1`),liveGroupMembers(id),fetchCoachRoster()]);const g=groups?.[0];if(!g)throw new Error('Group not found');const assigned=roster.athletes||[],memberIds=new Set(members.map(m=>m.athlete_id));mwModal(g.name,`<div class="tile"><h3>${escapeHtml(g.event_group||'Team Group')}</h3><p>${escapeHtml(g.description||'Manage this group roster.')}</p></div><div class="form" style="margin-top:12px"><label>Add Assigned Athlete<select id="groupAthlete"><option value="">Select athlete</option>${assigned.filter(a=>!memberIds.has(a.id)).map(a=>`<option value="${a.id}">${escapeHtml(a.name)}</option>`).join('')}</select></label><button class="action" id="addGroupAthlete">Add Athlete</button></div><div class="list" style="margin-top:12px">${assigned.filter(a=>memberIds.has(a.id)).map(a=>`<div class="row"><span><b>${escapeHtml(a.name)}</b><br><small>${escapeHtml(a.event||'Events not set')}</small></span><button class="back remove-member" data-athlete="${a.id}">Remove</button></div>`).join('')||'<div class="tile">No athletes in this group yet.</div>'}</div><div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:14px"><button class="action" id="messageGroup">Message Group</button><button class="back" id="groupAttendance">Take Attendance</button></div>`);document.getElementById('addGroupAthlete').onclick=async()=>{const aid=groupAthlete.value;if(!aid)return toast('Select an athlete');const u=await mwCurrentUser();try{await sbRest('coach_group_members',{method:'POST',body:{group_id:id,athlete_id:aid,added_by:u.id}});await logCoachAction('athlete_added_to_group','coach_group',id,{athlete_id:aid});document.getElementById('mwModal')?.remove();groupWorkspaceLive(id)}catch(e){toast(e.message)}};document.querySelectorAll('.remove-member').forEach(b=>b.onclick=async()=>{try{await sbRest(`coach_group_members?group_id=eq.${encodeURIComponent(id)}&athlete_id=eq.${encodeURIComponent(b.dataset.athlete)}`,{method:'DELETE',prefer:'return=minimal'});document.getElementById('mwModal')?.remove();groupWorkspaceLive(id)}catch(e){toast(e.message)}});messageGroup.onclick=()=>{document.getElementById('mwModal')?.remove();messagesPage(id)};groupAttendance.onclick=()=>{document.getElementById('mwModal')?.remove();attendancePage()};}catch(e){toast(e.message)}
}
async function programsPage(){
  if(experience==='performance')return mwTrackPage();
  pageBase('My Program','Build, upload, save and manage your own coaching program in the MW workspace.',`<div style="display:flex;justify-content:flex-end;gap:10px;flex-wrap:wrap;margin-bottom:14px"><button class="back" id="uploadProgram">Upload PDF / Word / Excel</button><button class="action" id="newProgram">+ New Program</button></div><div id="programLive" class="list"><div class="tile">Loading programs…</div></div>`);
  document.getElementById('newProgram').onclick=()=>programEditor();document.getElementById('uploadProgram').onclick=()=>programEditor(null,true);const wrap=document.getElementById('programLive');
  try{const rows=await sbRest('coach_programs?select=id,name,program_type,status,content,updated_at&order=updated_at.desc')||[];wrap.innerHTML=rows.map(x=>`<div class="row"><span><b>${escapeHtml(x.name)}</b><br><small>${escapeHtml(x.program_type||'track')} · ${escapeHtml(x.status||'draft')} · updated ${fmtDate(x.updated_at)}${x.content?.source_file?' · imported from '+escapeHtml(x.content.source_file):''}</small></span><button class="action program-open" data-id="${x.id}">Open</button></div>`).join('')||'<div class="tile">No coach-authored programs yet.</div>';wrap.querySelectorAll('.program-open').forEach(b=>b.onclick=()=>programEditor(b.dataset.id));}catch(e){wrap.innerHTML=`<div class="tile">${escapeHtml(e.message)}</div>`}
}
function readFileBase64(file){return new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(String(r.result||'').split(',')[1]||'');r.onerror=()=>reject(new Error('Could not read that file.'));r.readAsDataURL(file)})}
async function importCoachProgramFile(modal){
  const file=modal.querySelector('#cpFile')?.files?.[0],btn=modal.querySelector('#importCP'),state=modal.querySelector('#cpImportState');if(!file)return toast('Choose a PDF, Word, Excel, CSV, or TXT file first.');if(file.size>3*1024*1024)return toast('Keep the program file under 3 MB.');
  btn.disabled=true;btn.textContent='Reading & Converting…';state.textContent='MW is reading your program. You will review it before saving.';
  try{const dataBase64=await readFileBase64(file),r=await fetch('/api/coach/program-import',{method:'POST',headers:{Authorization:`Bearer ${mwSessionToken()}`,'Content-Type':'application/json'},body:JSON.stringify({fileName:file.name,mimeType:file.type,dataBase64})}),d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.error||'Program import failed.');if(!modal.querySelector('#cpName').value.trim())modal.querySelector('#cpName').value=d.suggestedName||file.name;modal.querySelector('#cpType').value=d.suggestedType||'track';modal.querySelector('#cpContent').value=d.programText||'';modal.dataset.sourceFile=file.name;state.innerHTML=`<b>✓ Program converted.</b><br>Review every week, day, rep, set, distance and recovery before saving.${d.warning?`<br><small>${escapeHtml(d.warning)}</small>`:''}`;}catch(e){state.innerHTML=`<b>Import failed.</b><br>${escapeHtml(e.message)}`}finally{btn.disabled=false;btn.textContent='Read & Convert File'}
}
async function programEditor(id=null,openUploader=false){
  let row=null;if(id){try{row=(await sbRest(`coach_programs?select=*&id=eq.${encodeURIComponent(id)}&limit=1`))?.[0]}catch(e){return toast(e.message)}}const content=row?.content||{};
  const modal=mwModal(row?'Edit Program':'New Program',`<div class="form"><div class="tile"><h3>Import Existing Program</h3><p>Upload PDF, Word (.docx), Excel, CSV or TXT. MW will convert the file into editable text. Nothing is published until you review and save it.</p><input id="cpFile" type="file" accept=".pdf,.docx,.xlsx,.xls,.csv,.txt,text/plain,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel"><button class="back" id="importCP" type="button" style="margin-top:10px">Read & Convert File</button><div id="cpImportState" style="margin-top:10px;color:#adbdc8"></div></div><label>Name<input id="cpName" value="${escapeHtml(row?.name||'')}"></label><label>Type<select id="cpType"><option value="track">Track</option><option value="strength">Strength</option><option value="combined">Combined</option></select></label><label>Status<select id="cpStatus"><option value="draft">Draft</option><option value="active">Active</option><option value="archived">Archived</option></select></label><label>Program Content<textarea id="cpContent" rows="14" placeholder="Week / Day / Session structure…">${escapeHtml(content.text||'')}</textarea></label><div class="tile"><b>Coach Review Required</b><p>MW never silently changes your prescription. Verify all workouts before making the program active.</p></div><button class="action" id="saveCP">Save Program</button></div>`);
  modal.dataset.sourceFile=content.source_file||'';modal.querySelector('#cpType').value=row?.program_type||'track';modal.querySelector('#cpStatus').value=row?.status||'draft';modal.querySelector('#importCP').onclick=()=>importCoachProgramFile(modal);if(openUploader)setTimeout(()=>modal.querySelector('#cpFile')?.click(),80);
  modal.querySelector('#saveCP').onclick=async()=>{const u=await mwCurrentUser(),body={coach_user_id:u.id,name:modal.querySelector('#cpName').value.trim(),program_type:modal.querySelector('#cpType').value,status:modal.querySelector('#cpStatus').value,content:{text:modal.querySelector('#cpContent').value,updated_from:`MW Coach V${MW_APP_VERSION}`,source_file:modal.dataset.sourceFile||null,review_required:false}};if(!body.name)return toast('Program name required');if(!body.content.text.trim())return toast('Program content is required');try{const d=id?await sbRest(`coach_programs?id=eq.${encodeURIComponent(id)}`,{method:'PATCH',body}):await sbRest('coach_programs',{method:'POST',body});await logCoachAction(id?'program_updated':'program_created','coach_program',d?.[0]?.id||id,{name:body.name,source_file:body.content.source_file});modal.remove();programsPage();toast('Program synced')}catch(e){toast(e.message)}};
}
async function calendarPage(){pageBase('Calendar','Live practices, meets and team events synced to your coach account.',`<button class="action" id="addCalendar">+ Add Event</button><div class="list" id="calLive" style="margin-top:14px"><div class="tile">Loading events…</div></div>`);addCalendar.onclick=calendarEventModal;try{const rows=await sbRest('coach_calendar_events?select=id,title,event_type,starts_at,location,notes,registration_status&order=starts_at.asc')||[];calLive.innerHTML=rows.map(e=>`<div class="row"><span><b>${escapeHtml(e.title)}</b><br><small>${escapeHtml(e.event_type||'event')} · ${new Date(e.starts_at).toLocaleString()}${e.location?' · '+escapeHtml(e.location):''}</small></span><button class="action cal-live" data-id="${e.id}">Open</button></div>`).join('')||'<div class="tile">No events scheduled yet.</div>';calLive.querySelectorAll('.cal-live').forEach(b=>b.onclick=()=>calendarEventModal(b.dataset.id));}catch(e){calLive.innerHTML=`<div class="tile">${escapeHtml(e.message)}</div>`}}
async function calendarEventModal(id=null){let row=null;if(id)row=(await sbRest(`coach_calendar_events?select=*&id=eq.${encodeURIComponent(id)}&limit=1`))?.[0];const local=row?.starts_at?new Date(row.starts_at).toISOString().slice(0,16):'';mwModal(row?'Edit Event':'Add Event',`<div class="form"><label>Title<input id="ceTitle" value="${escapeHtml(row?.title||'')}"></label><label>Type<select id="ceType"><option value="practice">Practice</option><option value="meet">Meet</option><option value="testing">Testing</option><option value="other">Other</option></select></label><label>Date / Time<input id="ceStart" type="datetime-local" value="${local}"></label><label>Location<input id="ceLoc" value="${escapeHtml(row?.location||'')}"></label><label>Notes<textarea id="ceNotes" rows="3">${escapeHtml(row?.notes||'')}</textarea></label><button class="action" id="saveCE">Save Event</button></div>`);ceType.value=row?.event_type||'practice';saveCE.onclick=async()=>{const u=await mwCurrentUser(),body={coach_user_id:u.id,title:ceTitle.value.trim(),event_type:ceType.value,starts_at:new Date(ceStart.value).toISOString(),location:ceLoc.value.trim()||null,notes:ceNotes.value.trim()||null,registration_status:row?.registration_status||null};if(!body.title||!ceStart.value)return toast('Title and date required');try{const d=id?await sbRest(`coach_calendar_events?id=eq.${encodeURIComponent(id)}`,{method:'PATCH',body}):await sbRest('coach_calendar_events',{method:'POST',body});await logCoachAction(id?'calendar_updated':'calendar_created','calendar_event',d?.[0]?.id||id,{title:body.title,type:body.event_type});document.getElementById('mwModal')?.remove();calendarPage()}catch(e){toast(e.message)}}}
async function meetsPage(){pageBase('Meets','Meet schedule pulled from your live MW calendar.',`<div id="meetLive" class="list"><div class="tile">Loading meets…</div></div><button class="action" id="newMeet" style="margin-top:14px">+ Add Meet</button>`);newMeet.onclick=()=>calendarEventModal();try{const rows=await sbRest('coach_calendar_events?select=id,title,starts_at,location,registration_status,notes&event_type=eq.meet&order=starts_at.asc')||[];meetLive.innerHTML=rows.map(e=>`<div class="row"><span><b>${escapeHtml(e.title)}</b><br><small>${new Date(e.starts_at).toLocaleDateString()} · ${escapeHtml(e.location||'Location TBD')}</small></span><span class="status">${escapeHtml(e.registration_status||'Planned')}</span></div>`).join('')||'<div class="tile">No meets scheduled yet.</div>'}catch(e){meetLive.innerHTML=`<div class="tile">${escapeHtml(e.message)}</div>`}}
async function messagesPage(preselectGroup=null){
  if(window.__mwCoachMessagePoll){clearInterval(window.__mwCoachMessagePoll);window.__mwCoachMessagePoll=null}
  pageBase('Messages','One inbox. One conversation thread per athlete. Team announcements stay separate.',`
    <div class="mw-msg-tabs"><button class="back active" id="mwDirectTab" type="button">1:1 ATHLETE MESSAGES</button><button class="back" id="mwAnnouncementTab" type="button">TEAM / GROUP ANNOUNCEMENTS</button></div>
    <div id="mwDirectMessages" class="mw-message-layout">
      <section class="mw-conversation-pane">
        <div class="mw-message-search"><span>⌕</span><input id="mwMessageSearch" autocomplete="off" placeholder="Search athlete conversations"></div>
        <div id="mwCoachInbox" class="mw-conversation-list"><div class="tile">Loading conversations…</div></div>
      </section>
      <section class="mw-thread-pane" id="mwCoachThreadPane">
        <div class="mw-thread-empty" id="mwCoachThreadEmpty"><div class="mw-thread-empty-icon">💬</div><h3>Select an athlete</h3><p>Choose a conversation to view the complete coach ↔ athlete message thread.</p></div>
        <div id="mwCoachThread" hidden>
          <div class="mw-thread-head"><button class="back mw-thread-mobile-back" id="mwCoachThreadBack" type="button">← Messages</button><div><h3 id="mwCoachThreadName">Athlete</h3><small id="mwCoachThreadStatus">MW Athlete</small></div></div>
          <div id="mwCoachThreadList" class="mw-thread-list"></div>
          <div class="mw-thread-compose"><textarea id="mwCoachThreadText" rows="2" placeholder="Message athlete…"></textarea><button class="action" id="mwCoachThreadSend" type="button">Send</button></div>
          <div id="mwCoachThreadState" class="mw-thread-state"></div>
        </div>
      </section>
    </div>
    <div id="mwAnnouncementMessages" hidden>
      <div class="form mw-announcement-compose"><label>Audience<select id="msgAudience"><option value="all_assigned">All Assigned Athletes</option><option value="group">Group</option></select></label><label id="msgTargetWrap" style="display:none">Group<select id="msgTarget"></select></label><label>Announcement<textarea id="msgText" rows="4" placeholder="Team or group announcement…"></textarea></label><button class="action" id="sendMsg">Send Announcement</button></div>
      <div class="list" id="msgHistory" style="margin-top:16px"><div class="tile">Loading announcements…</div></div>
    </div>`);

  let groups=[],roster=[],coachMessages=[],athleteReplies=[],selectedAthleteId=null,activeMode=preselectGroup?'announcements':'direct';
  const directWrap=document.getElementById('mwDirectMessages'),announceWrap=document.getElementById('mwAnnouncementMessages'),directTab=document.getElementById('mwDirectTab'),announceTab=document.getElementById('mwAnnouncementTab');
  const esc=escapeHtml;
  const initials=name=>String(name||'A').split(/\s+/).filter(Boolean).slice(0,2).map(x=>x[0]?.toUpperCase()).join('')||'A';
  const fmtTime=v=>{if(!v)return '';const d=new Date(v),today=new Date();return d.toDateString()===today.toDateString()?d.toLocaleTimeString([],{hour:'numeric',minute:'2-digit'}):d.toLocaleDateString([],{month:'short',day:'numeric'})};
  const setMode=mode=>{activeMode=mode;const direct=mode==='direct';directWrap.hidden=!direct;announceWrap.hidden=direct;directTab.classList.toggle('active',direct);announceTab.classList.toggle('active',!direct)};
  directTab.onclick=()=>setMode('direct');announceTab.onclick=()=>setMode('announcements');setMode(activeMode);

  try{[groups,roster]=await Promise.all([liveGroups(),fetchCoachRoster().then(d=>d.athletes||[])]);}catch(e){toast(e.message)}

  const syncAnnouncementTarget=()=>{const type=msgAudience.value;msgTargetWrap.style.display=type==='group'?'block':'none';msgTarget.innerHTML=groups.map(g=>`<option value="${g.id}">${esc(g.name)}</option>`).join('');if(preselectGroup&&type==='group')msgTarget.value=preselectGroup};
  msgAudience.onchange=syncAnnouncementTarget;if(preselectGroup){msgAudience.value='group'}syncAnnouncementTarget();

  function directCoachMessagesFor(aid){
    const replies=athleteReplies.filter(r=>r.athlete_id===aid),replyParentIds=new Set(replies.map(r=>r.in_reply_to).filter(Boolean));
    return coachMessages.filter(m=>(m.audience_type==='athlete'&&m.athlete_id===aid)||replyParentIds.has(m.id));
  }
  function mergedThread(aid){
    return [...directCoachMessagesFor(aid).map(x=>({...x,kind:'coach'})),...athleteReplies.filter(r=>r.athlete_id===aid).map(x=>({...x,kind:'athlete'}))].sort((a,b)=>new Date(a.created_at)-new Date(b.created_at));
  }
  function inboxSummary(a){
    const thread=mergedThread(a.id),last=thread[thread.length-1],unread=athleteReplies.filter(r=>r.athlete_id===a.id&&!r.coach_read_at).length;
    return {last,unread};
  }
  function renderInbox(){
    const wrap=document.getElementById('mwCoachInbox'),q=String(document.getElementById('mwMessageSearch')?.value||'').trim().toLowerCase();
    const rows=roster.filter(a=>!q||String(a.name||'').toLowerCase().includes(q)).map(a=>({a,...inboxSummary(a)})).sort((x,y)=>new Date(y.last?.created_at||0)-new Date(x.last?.created_at||0));
    wrap.innerHTML=rows.length?rows.map(({a,last,unread})=>`<button class="mw-conversation-row ${selectedAthleteId===a.id?'active':''}" data-athlete-thread="${esc(a.id)}"><span class="mw-conversation-avatar">${esc(initials(a.name))}</span><span class="mw-conversation-copy"><span class="mw-conversation-top"><b>${esc(a.name||'Athlete')}</b><small>${fmtTime(last?.created_at)}</small></span><span class="mw-conversation-preview">${esc(last?.body||'Start a conversation')}</span></span>${unread?`<span class="mw-unread-dot" title="${unread} unread"></span>`:''}</button>`).join(''):'<div class="tile">No athlete conversations found.</div>';
    wrap.querySelectorAll('[data-athlete-thread]').forEach(b=>b.onclick=()=>openAthleteThread(b.dataset.athleteThread));
  }
  function renderThread(){
    const pane=document.getElementById('mwCoachThread'),empty=document.getElementById('mwCoachThreadEmpty'),aid=selectedAthleteId,a=roster.find(x=>x.id===aid);if(!aid||!a){pane.hidden=true;empty.hidden=false;return}
    empty.hidden=true;pane.hidden=false;document.getElementById('mwCoachThreadName').textContent=a.name||'Athlete';document.getElementById('mwCoachThreadStatus').textContent=a.event||'MW Athlete';
    const rows=mergedThread(aid),wrap=document.getElementById('mwCoachThreadList');wrap.innerHTML=rows.length?rows.map(x=>`<article class="mw-thread-bubble ${x.kind}"><div>${esc(x.body)}</div><small>${x.kind==='coach'?'You':'Athlete'} · ${new Date(x.created_at).toLocaleString()}</small></article>`).join(''):'<div class="mw-thread-empty-inline">No messages yet. Send the first message below.</div>';wrap.scrollTop=wrap.scrollHeight;
  }
  async function markThreadRead(aid){
    const ids=athleteReplies.filter(r=>r.athlete_id===aid&&!r.coach_read_at).map(r=>r.id);if(!ids.length)return;
    try{await sbRest(`athlete_coach_replies?id=in.(${ids.join(',')})`,{method:'PATCH',body:{coach_read_at:new Date().toISOString()},prefer:'return=minimal'});athleteReplies.forEach(r=>{if(ids.includes(r.id))r.coach_read_at=new Date().toISOString()})}catch{}
  }
  async function openAthleteThread(aid){selectedAthleteId=aid;renderInbox();renderThread();await markThreadRead(aid);renderInbox();document.getElementById('mwCoachThreadPane')?.classList.add('thread-open')}
  document.getElementById('mwCoachThreadBack').onclick=()=>document.getElementById('mwCoachThreadPane')?.classList.remove('thread-open');
  document.getElementById('mwMessageSearch').oninput=renderInbox;
  document.getElementById('mwCoachThreadSend').onclick=async()=>{const box=document.getElementById('mwCoachThreadText'),state=document.getElementById('mwCoachThreadState'),body=box.value.trim();if(!selectedAthleteId)return toast('Select an athlete');if(!body)return;const u=await mwCurrentUser(),btn=document.getElementById('mwCoachThreadSend');btn.disabled=true;state.textContent='Sending…';try{const d=await sbRest('coach_messages',{method:'POST',body:{coach_user_id:u.id,audience_type:'athlete',body,group_id:null,athlete_id:selectedAthleteId}});await logCoachAction('message_sent','coach_message',d?.[0]?.id,{audience:'athlete',athlete_id:selectedAthleteId});box.value='';state.textContent='';await loadAll();renderThread()}catch(e){state.textContent=e.message}finally{btn.disabled=false}};

  async function loadAnnouncements(){
    const rows=coachMessages.filter(m=>m.audience_type!=='athlete').sort((a,b)=>new Date(b.created_at)-new Date(a.created_at));
    msgHistory.innerHTML=rows.map(m=>`<div class="row"><span><b>${esc(m.audience_type==='group'?'Group Announcement':'All Assigned Athletes')}</b><br>${esc(m.body)}</span><small>${new Date(m.created_at).toLocaleString()}</small></div>`).join('')||'<div class="tile">No team or group announcements yet.</div>';
  }
  sendMsg.onclick=async()=>{const body=msgText.value.trim();if(!body)return toast('Write an announcement first');const u=await mwCurrentUser(),type=msgAudience.value,payload={coach_user_id:u.id,audience_type:type,body,group_id:type==='group'?msgTarget.value:null,athlete_id:null};try{const d=await sbRest('coach_messages',{method:'POST',body:payload});await logCoachAction('message_sent','coach_message',d?.[0]?.id,{audience:type});msgText.value='';await loadAll();toast('Announcement sent')}catch(e){toast(e.message)}};

  async function loadAll(){
    try{[coachMessages,athleteReplies]=await Promise.all([sbRest('coach_messages?select=id,athlete_id,group_id,audience_type,body,created_at&order=created_at.asc&limit=300'),sbRest('athlete_coach_replies?select=id,athlete_id,coach_user_id,in_reply_to,body,created_at,coach_read_at&order=created_at.asc&limit=300')]);coachMessages=coachMessages||[];athleteReplies=athleteReplies||[];renderInbox();renderThread();loadAnnouncements()}catch(e){document.getElementById('mwCoachInbox').innerHTML=`<div class="tile">${esc(e.message)}</div>`}
  }
  await loadAll();
  window.__mwCoachMessagePoll=setInterval(()=>{if(document.getElementById('mwCoachInbox'))loadAll()},12000);
}

async function activityPage(){pageBase('Activity Log','A real audit trail of coach actions in MW Dynasty.',`<div id="activityLive" class="list"><div class="tile">Loading activity…</div></div>`);try{const rows=await sbRest('coach_activity_log?select=id,action_type,entity_type,detail,created_at&order=created_at.desc&limit=50')||[];activityLive.innerHTML=rows.map(a=>`<div class="row"><span><b>${escapeHtml(a.action_type.replaceAll('_',' '))}</b><br><small>${escapeHtml(a.entity_type||'MW Coach')} ${a.detail?.name?'· '+escapeHtml(a.detail.name):''}</small></span><small>${new Date(a.created_at).toLocaleString()}</small></div>`).join('')||'<div class="tile">Activity will appear as you use the connected coach workspace.</div>'}catch(e){activityLive.innerHTML=`<div class="tile">${escapeHtml(e.message)}</div>`}}
async function taskBoardPage(){pageBase('Coach Task Board','Live priorities generated from athlete performance, program state and training activity.',`<div id="taskLive" class="list"><div class="tile">Analyzing assigned athletes…</div></div>`);try{const [d,p]=await Promise.all([fetchCoachRoster(),fetchCoachPerformance().catch(()=>({athletes:[]}))]),a=d.athletes||[],pm=new Map((p.athletes||[]).map(x=>[x.athlete_id,x])),tasks=[];for(const x of a){const perf=pm.get(x.id);for(const f of (perf?.flags||[]))tasks.push({n:x.name,d:f.message,p:f.level==='attention'?'Review Now':'Watch'});if(!x.last_completed_workout_at)tasks.push({n:x.name,d:'No completed workout is currently recorded. Review training status.',p:'Review'});else{const days=(Date.now()-new Date(x.last_completed_workout_at).getTime())/86400000;if(days>7)tasks.push({n:x.name,d:`Last recorded workout was ${Math.floor(days)} days ago. Check attendance and readiness.`,p:'High'});}if((x.prs||[]).length===0)tasks.push({n:x.name,d:'No PRs are recorded. Add verified marks to unlock individualized pacing.',p:'Setup'});}taskLive.innerHTML=tasks.map(t=>`<div class="row"><span><b>${escapeHtml(t.n)}</b><br>${escapeHtml(t.d)}</span><span class="status">${t.p}</span></div>`).join('')||'<div class="tile"><h3>No urgent athlete tasks detected</h3><p>No performance review flags, basic data gaps, or inactivity signals are active right now.</p></div>'}catch(e){taskLive.innerHTML=`<div class="tile">${escapeHtml(e.message)}</div>`}}
async function insightsPage(){
  pageBase('Performance Intelligence','Live coaching intelligence from your assigned athletes.',`<div id="insightLive" class="panel-grid"><div class="tile">Analyzing recorded performance…</div></div><div id="athletePerformanceLive" class="list" style="margin-top:16px"></div>`);
  try{
    const [d,p]=await Promise.all([fetchCoachRoster(),fetchCoachPerformance()]),a=d.athletes||[],pm=new Map((p.athletes||[]).map(x=>[x.athlete_id,x])),s=p.summary||{},rep=p.rep_tracking_enabled!==false;
    if(!rep){
      insightLive.innerHTML=`<div class="tile mw-upgrade-teaser"><div class="mw-upgrade-lock">🔒</div><div><div class="eyebrow">MW SPRINT PERFORMANCE</div><h3>Rep-by-Rep Sprint Tracking</h3><p>Track every rep, pace execution, consistency and late-session drop-off inside the complete MW Sprint Performance System.</p><button class="action" id="upgradeRepTracking">Upgrade to MW Sprint Performance</button></div></div><div class="tile"><h3>Strength Intelligence</h3><p><b>${s.athletes_with_strength_data||0}</b> of ${a.length} athletes have strength data connected.</p><small>Coach Intelligence continues to analyze available strength and training signals.</small></div>`;
      document.getElementById('upgradeRepTracking').onclick=membershipPage;
      athletePerformanceLive.innerHTML=a.map(x=>{const q=pm.get(x.id),flags=q?.flags||[],flag=flags[0];return `<button class="row" data-athlete-id="${escapeHtml(x.id)}" style="width:100%;text-align:left"><span><b>${escapeHtml(x.name)}</b><br><small>${q?.strength?.session_count?`${q.strength.session_count} strength session${q.strength.session_count===1?'':'s'} recorded`:'No strength session data yet'}</small><br><small>${escapeHtml(flag?.message||'Training status available for coach review')}</small></span><span class="status">INTELLIGENCE</span></button>`}).join('')||'<div class="tile">No assigned athletes yet.</div>';
    }else{
      insightLive.innerHTML=`<div class="tile"><h3>Pace Check-Ins</h3><p><b>${s.athletes_with_sprint_data||0}</b> of ${a.length} athletes</p><small>Quick check-ins or detailed Sprint Pace AI results</small></div><div class="tile"><h3>Pace Execution</h3><p><b>${s.average_latest_execution_pct==null?'—':s.average_latest_execution_pct+'%'}</b></p><small>Roster average across latest pace check-ins</small></div><div class="tile"><h3>Coach Review</h3><p><b>${s.review_flags||0}</b> review · <b>${s.watch_flags||0}</b> watch</p><small>Signals for coach judgment, not automatic changes</small></div><div class="tile"><h3>Strength Data</h3><p><b>${s.athletes_with_strength_data||0}</b> of ${a.length} athletes</p><small>Quick strength check-ins or detailed set logs</small></div>`;
      athletePerformanceLive.innerHTML=a.map(x=>{const q=pm.get(x.id),latest=q?.sprint?.latest,flag=q?.flags?.[0];return `<button class="row" data-athlete-id="${escapeHtml(x.id)}" style="width:100%;text-align:left"><span><b>${escapeHtml(x.name)}</b><br><small>${latest?`Week ${latest.program_week} · Day ${latest.program_day} · ${latest.source==='quick_checkin'?`${latest.pace_reps_hit}/${latest.pace_reps_total} on pace`:`${latest.rep_count} timed reps`}`:'No pace check-in yet'}${q?.strength?.session_count?` · ${q.strength.session_count} strength session${q.strength.session_count===1?'':'s'}`:''}</small><br><small>${escapeHtml(flag?.message||latest?.reason||'Awaiting performance data')}</small></span><span class="status">${latest?.execution_score_pct==null?'—':latest.execution_score_pct+'%'}</span></button>`}).join('')||'<div class="tile">No assigned athletes yet.</div>';
    }
    athletePerformanceLive.querySelectorAll('[data-athlete-id]').forEach(b=>b.onclick=()=>athleteDetail(b.dataset.athleteId));
  }catch(e){insightLive.innerHTML=`<div class="tile"><h3>Performance intelligence unavailable</h3><p>${escapeHtml(e.message)}</p></div>`}
}

async function pacingPage(){pageBase('Pacing Tools','Choose a live athlete PR and calculate individualized training targets.',`<div class="form"><label>Athlete<select id="paceAthlete"></select></label><label>PR<select id="pacePr"></select></label><label>Rep Distance<input id="rd" type="number" value="150"></label><label>Intensity %<input id="pi" type="number" value="90" min="50" max="100"></label><button class="action" id="calc">Calculate Target</button><div id="paceout" class="tile">Loading athlete PRs…</div></div>`);try{const a=(await fetchCoachRoster()).athletes||[];paceAthlete.innerHTML=a.map((x,i)=>`<option value="${i}">${escapeHtml(x.name)}</option>`).join('');const sync=()=>{const x=a[+paceAthlete.value],prs=x?.prs||[];pacePr.innerHTML=prs.map((p,i)=>`<option value="${i}">${escapeHtml(p.event)} — ${Number(p.time_seconds).toFixed(2)}s</option>`).join('');paceout.textContent=prs.length?'Select distance and intensity.':'This athlete needs a recorded PR first.'};paceAthlete.onchange=sync;sync();calc.onclick=()=>{const x=a[+paceAthlete.value],p=x?.prs?.[+pacePr.value];if(!p)return toast('Select an athlete with a PR');const base=Number(String(p.event).replace(/[^0-9.]/g,'')),pr=Number(p.time_seconds),dist=+rd.value,int=+pi.value;if(!(base>0&&pr>0&&dist>0&&int>=50&&int<=100))return toast('Check pacing inputs');const t=dist/((base/pr)*(int/100));paceout.innerHTML=`<b>${escapeHtml(x.name)}</b><br>${dist}m at ${int}% → <b>${t.toFixed(2)}s</b><br><small>Based on ${escapeHtml(p.event)} PR of ${pr.toFixed(2)}s</small>`}}catch(e){paceout.textContent=e.message}}
const MW_FIELD_CIRCUIT_REFERENCE={
  structure:'2 sets · 2 full-circuit reps per set · 4 full circuits total · 8 × 100m sprints',
  steps:[
    '100m sprint',
    '30 sec walk / rest through the first half of the end zone',
    'Bear crawl through the second half of the end zone',
    '15 sec rest at the corner',
    '100m sprint back',
    '30 sec walk / rest through the first half of the end zone',
    'High knees through the second half of the end zone',
    '15 sec rest at the corner'
  ]
};
function mwDetailLine(label,value){return value?`<div class="mw-detail-line"><span>${escapeHtml(label)}</span><b>${escapeHtml(value)}</b></div>`:''}
function mwOrdered(items){return Array.isArray(items)&&items.length?`<ol class="mw-order-list">${items.map(x=>`<li>${escapeHtml(x)}</li>`).join('')}</ol>`:''}
function mwCueList(items){return Array.isArray(items)&&items.length?`<div class="mw-cues">${items.map(x=>`<span>✓ ${escapeHtml(x)}</span>`).join('')}</div>`:''}
function renderTrackSession(s){
  const genericCircuit=s.title==='General Sprint Circuit'&&!s.circuit;
  const circuit=genericCircuit?MW_FIELD_CIRCUIT_REFERENCE.steps:s.circuit;
  const structure=genericCircuit?MW_FIELD_CIRCUIT_REFERENCE.structure:s.structure;
  return `<section class="mw-session-card">
    <div class="mw-session-top"><div><small>DAY ${escapeHtml(s.day)}</small><h3>${escapeHtml(s.title||s.focus||'Session')}</h3></div>${s.intensity?`<span class="mw-chip">${escapeHtml(s.intensity)}</span>`:''}</div>
    ${mwDetailLine('Focus',s.focus)}
    ${mwDetailLine('Work',s.work)}
    ${mwDetailLine('Setup',s.setup)}
    ${mwDetailLine('Structure',structure)}
    ${Array.isArray(s.sequence)&&s.sequence.length?`<div class="mw-detail-block"><b>Sequence</b>${mwOrdered(s.sequence)}</div>`:''}
    ${Array.isArray(circuit)&&circuit.length?`<div class="mw-detail-block mw-circuit-block"><b>${genericCircuit?'General Sprint Circuit · MW Field Circuit Reference':'Circuit · Exact Movement Order'}</b>${genericCircuit?`<p class="mw-reference-note">Coach reference: use this visual to understand the MW field-circuit flow. The weekly session card remains the source for the prescribed volume and intensity.</p>`:''}${mwOrdered(circuit)}${genericCircuit?`<img class="mw-circuit-img" src="mw-field-circuit-reference.png" alt="MW Field Circuit training diagram">`:''}</div>`:''}
    ${mwDetailLine('Recovery',s.recovery)}
    ${mwCueList(s.cues)}
  </section>`;
}
function mwStrengthDayLabel(code){
  return ({MON:'MONDAY',TUE:'TUESDAY',WED:'WEDNESDAY',THU:'THURSDAY',FRI:'FRIDAY',SAT:'SATURDAY',SUN:'SUNDAY'})[code]||code||'SESSION';
}
function mwStrengthGroups(sections){
  const groups=[];
  (sections||[]).forEach(sec=>{
    const raw=String(sec.title||'Session');
    const m=raw.match(/^(MON|TUE|WED|THU|FRI|SAT|SUN)\s*-\s*(.*)$/i);
    const code=(m?.[1]||'SESSION').toUpperCase();
    const title=m?.[2]||raw;
    let g=groups.find(x=>x.code===code);
    if(!g){g={code,label:mwStrengthDayLabel(code),blocks:[]};groups.push(g)}
    g.blocks.push({title,entries:sec.entries||[]});
  });
  return groups;
}
function renderStrengthWeek(x,week){
  const groups=mwStrengthGroups(x.sections||[]);
  return `<div class="mw-strength-week mw-strength-readable">
    <div class="mw-week-banner"><small>MW STRENGTH & POWER · ${escapeHtml(x.tierLabel||'FOUNDATION')}</small><h3>${escapeHtml(x.title||`Week ${week}`)}</h3>${x.phaseName?`<p>${escapeHtml(x.phaseName)}</p>`:''}<div class="mw-week-guide">Exercise <span>•</span> Prescription <span>•</span> Circuits <span>•</span> Coach note</div></div>
    ${x.tierGuidance?`<section class="mw-coach-note"><b>${escapeHtml(x.tierLabel||'')} TIER RULES</b><p>${escapeHtml(x.tierGuidance.volume||'')} ${escapeHtml(x.tierGuidance.effort||'')} ${escapeHtml(x.tierGuidance.loading||'')} ${escapeHtml(x.tierGuidance.priority||'')}</p></section>`:''}
    ${groups.map((g,gi)=>`<details class="mw-day-card" ${gi===0?'open':''}>
      <summary><span><small>TRAINING DAY</small><b>${escapeHtml(g.label)}</b></span><span class="mw-day-toggle">⌄</span></summary>
      <div class="mw-day-body">${g.blocks.map(block=>`<section class="mw-strength-block">
        <div class="mw-strength-block-title">${escapeHtml(block.title)}</div>
        <div class="mw-strength-table"><div class="mw-strength-head"><span>EXERCISE</span><span>PRESCRIPTION</span></div>
        ${(block.entries||[]).map(row=>`<div class="mw-lift-row"><b>${escapeHtml(row?.[0]||'')}</b><span>${escapeHtml(row?.[1]||'')}</span></div>`).join('')}</div>
      </section>`).join('')}</div>
    </details>`).join('')}
    ${x.coachNote?`<section class="mw-coach-note"><b>COACH MW NOTE</b><p>${escapeHtml(x.coachNote)}</p></section>`:''}
  </div>`;
}
async function mwProgramWeek(week,kind='track'){
  try{
    const token=mwSessionToken();
    const r=await fetch(`/api/coach/program?week=${week}`,{headers:{Authorization:`Bearer ${token}`}});
    const d=await r.json();
    if(!r.ok)throw new Error(d.error||'Program unavailable');
    const x=kind==='strength'?d.strength:d.track;
    if(!x)return mwModal(`${kind==='strength'?'Strength & Power':'MW Track Program'} · Week ${week}`,'<div class="tile">No verified prescription is connected for this week.</div>');
    const body=kind==='strength'?renderStrengthWeek(x,week):`<div class="mw-track-week"><div class="mw-week-banner"><small>MW TRACK PROGRAM</small><h3>Week ${week} · ${escapeHtml(x.phaseName||'MW Sprint Development')}</h3></div>${(x.sessions||[]).map(renderTrackSession).join('')}</div>`;
    mwModal(`${kind==='strength'?'Strength & Power':'MW Track Program'} · Week ${week}`,body);
  }catch(e){toast(e.message)}
}
function mwTrackPage(){pageBase('MW Track Program','Protected 41-week MW training system — every session opens with the full prescription, recovery, cues and circuit order.',`<div class="panel-grid">${Array.from({length:41},(_,i)=>i+1).map(w=>`<div class="tile"><h3>Week ${w}</h3><p>MW progressive sprint development</p><button class="action mw-week" data-week="${w}">Open Week</button></div>`).join('')}</div>`);document.querySelectorAll('.mw-week').forEach(b=>b.onclick=()=>mwProgramWeek(+b.dataset.week,'track'))}
function strengthPage(){pageBase('Strength & Power','The complete MW weight-room plan — organized by training day, lift, prescription, circuits and Coach MW notes.',`<div class="panel-grid">${Array.from({length:41},(_,i)=>i+1).map(w=>`<div class="tile"><h3>Week ${w}</h3><p>MW Strength & Power</p><button class="action mw-strength" data-week="${w}">Open Week</button></div>`).join('')}</div>`);document.querySelectorAll('.mw-strength').forEach(b=>b.onclick=()=>mwProgramWeek(+b.dataset.week,'strength'))}

initAuth();
